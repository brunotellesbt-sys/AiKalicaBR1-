(() => {
  "use strict";
  const VERSION = "v8-kanto-johto-routes-topdown";
  const SAVE_KEY = "pokelike_gen12_save_v8";
  const SPRITE_FRONT = id => `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-ii/crystal/${id}.png`;
  const SPRITE_BACK = id => `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-ii/crystal/back/${id}.png`;
  const SPRITE_FALLBACK = id => `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;
  const ITEM_SPRITE = name => `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/${name}.png`;

  const POKEMON_NAMES = [
    "Bulbasaur","Ivysaur","Venusaur","Charmander","Charmeleon","Charizard","Squirtle","Wartortle","Blastoise","Caterpie","Metapod","Butterfree","Weedle","Kakuna","Beedrill","Pidgey","Pidgeotto","Pidgeot","Rattata","Raticate","Spearow","Fearow","Ekans","Arbok","Pikachu","Raichu","Sandshrew","Sandslash","Nidoran♀","Nidorina","Nidoqueen","Nidoran♂","Nidorino","Nidoking","Clefairy","Clefable","Vulpix","Ninetales","Jigglypuff","Wigglytuff","Zubat","Golbat","Oddish","Gloom","Vileplume","Paras","Parasect","Venonat","Venomoth","Diglett","Dugtrio","Meowth","Persian","Psyduck","Golduck","Mankey","Primeape","Growlithe","Arcanine","Poliwag","Poliwhirl","Poliwrath","Abra","Kadabra","Alakazam","Machop","Machoke","Machamp","Bellsprout","Weepinbell","Victreebel","Tentacool","Tentacruel","Geodude","Graveler","Golem","Ponyta","Rapidash","Slowpoke","Slowbro","Magnemite","Magneton","Farfetch'd","Doduo","Dodrio","Seel","Dewgong","Grimer","Muk","Shellder","Cloyster","Gastly","Haunter","Gengar","Onix","Drowzee","Hypno","Krabby","Kingler","Voltorb","Electrode","Exeggcute","Exeggutor","Cubone","Marowak","Hitmonlee","Hitmonchan","Lickitung","Koffing","Weezing","Rhyhorn","Rhydon","Chansey","Tangela","Kangaskhan","Horsea","Seadra","Goldeen","Seaking","Staryu","Starmie","Mr. Mime","Scyther","Jynx","Electabuzz","Magmar","Pinsir","Tauros","Magikarp","Gyarados","Lapras","Ditto","Eevee","Vaporeon","Jolteon","Flareon","Porygon","Omanyte","Omastar","Kabuto","Kabutops","Aerodactyl","Snorlax","Articuno","Zapdos","Moltres","Dratini","Dragonair","Dragonite","Mewtwo","Mew",
    "Chikorita","Bayleef","Meganium","Cyndaquil","Quilava","Typhlosion","Totodile","Croconaw","Feraligatr","Sentret","Furret","Hoothoot","Noctowl","Ledyba","Ledian","Spinarak","Ariados","Crobat","Chinchou","Lanturn","Pichu","Cleffa","Igglybuff","Togepi","Togetic","Natu","Xatu","Mareep","Flaaffy","Ampharos","Bellossom","Marill","Azumarill","Sudowoodo","Politoed","Hoppip","Skiploom","Jumpluff","Aipom","Sunkern","Sunflora","Yanma","Wooper","Quagsire","Espeon","Umbreon","Murkrow","Slowking","Misdreavus","Unown","Wobbuffet","Girafarig","Pineco","Forretress","Dunsparce","Gligar","Steelix","Snubbull","Granbull","Qwilfish","Scizor","Shuckle","Heracross","Sneasel","Teddiursa","Ursaring","Slugma","Magcargo","Swinub","Piloswine","Corsola","Remoraid","Octillery","Delibird","Mantine","Skarmory","Houndour","Houndoom","Kingdra","Phanpy","Donphan","Porygon2","Stantler","Smeargle","Tyrogue","Hitmontop","Smoochum","Elekid","Magby","Miltank","Blissey","Raikou","Entei","Suicune","Larvitar","Pupitar","Tyranitar","Lugia","Ho-Oh","Celebi"
  ];
  const TYPE_FALLBACKS = {
    1:["grass","poison"],2:["grass","poison"],3:["grass","poison"],4:["fire"],5:["fire"],6:["fire","flying"],7:["water"],8:["water"],9:["water"],
    10:["bug"],11:["bug"],12:["bug","flying"],13:["bug","poison"],14:["bug","poison"],15:["bug","poison"],16:["normal","flying"],17:["normal","flying"],18:["normal","flying"],19:["normal"],20:["normal"],21:["normal","flying"],22:["normal","flying"],23:["poison"],24:["poison"],25:["electric"],26:["electric"],27:["ground"],28:["ground"],
    37:["fire"],38:["fire"],41:["poison","flying"],42:["poison","flying"],43:["grass","poison"],44:["grass","poison"],45:["grass","poison"],50:["ground"],51:["ground"],54:["water"],55:["water"],58:["fire"],59:["fire"],60:["water"],61:["water"],62:["water","fighting"],63:["psychic"],64:["psychic"],65:["psychic"],66:["fighting"],67:["fighting"],68:["fighting"],69:["grass","poison"],70:["grass","poison"],71:["grass","poison"],72:["water","poison"],73:["water","poison"],74:["rock","ground"],75:["rock","ground"],76:["rock","ground"],77:["fire"],78:["fire"],79:["water","psychic"],80:["water","psychic"],81:["electric","steel"],82:["electric","steel"],
    92:["ghost","poison"],93:["ghost","poison"],94:["ghost","poison"],95:["rock","ground"],96:["psychic"],97:["psychic"],98:["water"],99:["water"],100:["electric"],101:["electric"],102:["grass","psychic"],103:["grass","psychic"],104:["ground"],105:["ground"],109:["poison"],110:["poison"],111:["ground","rock"],112:["ground","rock"],113:["normal"],114:["grass"],116:["water"],117:["water"],118:["water"],119:["water"],120:["water"],121:["water","psychic"],123:["bug","flying"],124:["ice","psychic"],125:["electric"],126:["fire"],127:["bug"],129:["water"],130:["water","flying"],131:["water","ice"],133:["normal"],134:["water"],135:["electric"],136:["fire"],138:["rock","water"],139:["rock","water"],140:["rock","water"],141:["rock","water"],142:["rock","flying"],143:["normal"],144:["ice","flying"],145:["electric","flying"],146:["fire","flying"],147:["dragon"],148:["dragon"],149:["dragon","flying"],150:["psychic"],151:["psychic"],
    152:["grass"],153:["grass"],154:["grass"],155:["fire"],156:["fire"],157:["fire"],158:["water"],159:["water"],160:["water"],161:["normal"],162:["normal"],163:["normal","flying"],164:["normal","flying"],165:["bug","flying"],166:["bug","flying"],167:["bug","poison"],168:["bug","poison"],169:["poison","flying"],170:["water","electric"],171:["water","electric"],172:["electric"],173:["normal"],174:["normal"],175:["normal"],176:["normal","flying"],177:["psychic","flying"],178:["psychic","flying"],179:["electric"],180:["electric"],181:["electric"],182:["grass"],183:["water"],184:["water"],185:["rock"],186:["water"],187:["grass","flying"],188:["grass","flying"],189:["grass","flying"],190:["normal"],191:["grass"],192:["grass"],193:["bug","flying"],194:["water","ground"],195:["water","ground"],196:["psychic"],197:["dark"],198:["dark","flying"],199:["water","psychic"],200:["ghost"],201:["psychic"],202:["psychic"],203:["normal","psychic"],204:["bug"],205:["bug","steel"],206:["normal"],207:["ground","flying"],208:["steel","ground"],209:["normal"],210:["normal"],211:["water","poison"],212:["bug","steel"],213:["bug","rock"],214:["bug","fighting"],215:["dark","ice"],216:["normal"],217:["normal"],218:["fire"],219:["fire","rock"],220:["ice","ground"],221:["ice","ground"],222:["water","rock"],223:["water"],224:["water"],225:["ice","flying"],226:["water","flying"],227:["steel","flying"],228:["dark","fire"],229:["dark","fire"],230:["water","dragon"],231:["ground"],232:["ground"],233:["normal"],234:["normal"],235:["normal"],236:["fighting"],237:["fighting"],238:["ice","psychic"],239:["electric"],240:["fire"],241:["normal"],242:["normal"],243:["electric"],244:["fire"],245:["water"],246:["rock","ground"],247:["rock","ground"],248:["rock","dark"],249:["psychic","flying"],250:["fire","flying"],251:["psychic","grass"]
  };
  const EVOS = {
    1:[16,2],2:[32,3],4:[16,5],5:[36,6],7:[16,8],8:[36,9],10:[7,11],11:[10,12],13:[7,14],14:[10,15],16:[18,17],17:[36,18],19:[20,20],21:[20,22],23:[22,24],25:[22,26],27:[22,28],29:[16,30],30:[36,31],32:[16,33],33:[36,34],35:[25,36],37:[25,38],39:[22,40],41:[22,42],42:[32,169],43:[21,44],44:[32,45],46:[24,47],48:[31,49],50:[26,51],52:[28,53],54:[33,55],56:[28,57],58:[34,59],60:[25,61],61:[35,62],63:[16,64],64:[32,65],66:[28,67],67:[40,68],69:[21,70],70:[32,71],72:[30,73],74:[25,75],75:[40,76],77:[40,78],79:[37,80],81:[30,82],84:[31,85],86:[34,87],88:[38,89],90:[30,91],92:[25,93],93:[38,94],96:[26,97],98:[28,99],100:[30,101],102:[30,103],104:[28,105],109:[35,110],111:[42,112],116:[32,117],118:[33,119],120:[32,121],129:[20,130],138:[40,139],140:[40,141],147:[30,148],148:[55,149],
    152:[16,153],153:[32,154],155:[14,156],156:[36,157],158:[18,159],159:[30,160],161:[15,162],163:[20,164],165:[18,166],167:[22,168],170:[27,171],172:[18,25],173:[18,35],174:[18,39],175:[18,176],177:[25,178],179:[15,180],180:[30,181],183:[18,184],187:[18,188],188:[27,189],191:[18,192],194:[20,195],204:[31,205],209:[23,210],216:[30,217],218:[38,219],220:[33,221],223:[25,224],228:[24,229],231:[25,232],236:[20,237],238:[30,124],239:[30,125],240:[30,126],246:[30,247],247:[55,248]
  };

  const STARTERS = { johto: [152,155,158], kanto:[1,4,7] };
  const TYPE_NAMES = ["normal","fire","water","electric","grass","ice","fighting","poison","ground","flying","psychic","bug","rock","ghost","dragon","dark","steel"];
  const ITEMS = {
    potion:{name:"Potion", sprite:"potion", price:300, desc:"Cura 20 HP", use:"heal", value:20},
    superPotion:{name:"Super Potion", sprite:"super-potion", price:700, desc:"Cura 50 HP", use:"heal", value:50},
    revive:{name:"Revive", sprite:"revive", price:1500, desc:"Revive 50% HP", use:"revive", value:.5},
    rareCandy:{name:"Rare Candy", sprite:"rare-candy", price:2400, desc:"Sobe 1 nível", use:"level", value:1},
    pokeball:{name:"Poké Ball", sprite:"poke-ball", price:200, desc:"Usada no nó de captura", use:"catch", value:1},
    greatball:{name:"Great Ball", sprite:"great-ball", price:600, desc:"Mais chance de captura", use:"catch", value:1.35},
    escapeRope:{name:"Escape Rope", sprite:"escape-rope", price:550, desc:"Foge de batalha selvagem", use:"escape", value:1}
  };
  const EFFECT = {
    normal:{rock:.5,ghost:0,steel:.5}, fire:{fire:.5,water:.5,grass:2,ice:2,bug:2,rock:.5,dragon:.5,steel:2}, water:{fire:2,water:.5,grass:.5,ground:2,rock:2,dragon:.5}, electric:{water:2,electric:.5,grass:.5,ground:0,flying:2,dragon:.5}, grass:{fire:.5,water:2,grass:.5,poison:.5,ground:2,flying:.5,bug:.5,rock:2,dragon:.5,steel:.5}, ice:{fire:.5,water:.5,grass:2,ice:.5,ground:2,flying:2,dragon:2,steel:.5}, fighting:{normal:2,ice:2,poison:.5,flying:.5,psychic:.5,bug:.5,rock:2,ghost:0,dark:2,steel:2}, poison:{grass:2,poison:.5,ground:.5,rock:.5,ghost:.5,steel:0}, ground:{fire:2,electric:2,grass:.5,poison:2,flying:0,bug:.5,rock:2,steel:2}, flying:{electric:.5,grass:2,fighting:2,bug:2,rock:.5,steel:.5}, psychic:{fighting:2,poison:2,psychic:.5,dark:0,steel:.5}, bug:{fire:.5,grass:2,fighting:.5,poison:.5,flying:.5,psychic:2,ghost:.5,dark:2,steel:.5}, rock:{fire:2,ice:2,fighting:.5,ground:.5,flying:2,bug:2,steel:.5}, ghost:{normal:0,psychic:2,ghost:2,dark:.5,steel:.5}, dragon:{dragon:2,steel:.5}, dark:{fighting:.5,psychic:2,ghost:2,dark:.5,steel:.5}, steel:{fire:.5,water:.5,electric:.5,ice:2,rock:2,steel:.5}
  };
  const MOVE_POOL = {
    normal:["Tackle","Quick Attack","Headbutt"], fire:["Ember","Flame Wheel","Fire Punch"], water:["Water Gun","Bubble Beam","Aqua Tail"], grass:["Vine Whip","Razor Leaf","Mega Drain"], electric:["Thunder Shock","Spark","Thunder Punch"], ice:["Powder Snow","Ice Punch","Aurora Beam"], fighting:["Karate Chop","Low Kick","Double Kick"], poison:["Poison Sting","Acid","Sludge"], ground:["Mud-Slap","Dig","Magnitude"], flying:["Gust","Wing Attack","Aerial Ace"], psychic:["Confusion","Psybeam","Psychic"], bug:["Bug Bite","Twinneedle","Fury Cutter"], rock:["Rock Throw","Ancient Power","Rock Slide"], ghost:["Lick","Night Shade","Shadow Ball"], dragon:["Twister","Dragon Breath","Dragon Rage"], dark:["Bite","Faint Attack","Pursuit"], steel:["Metal Claw","Iron Tail","Steel Wing"]
  };

  const TRAINER_CLASSES = {
    youngster:{label:"Youngster", skin:"#f0c49c", hat:"#4da3ff", shirt:"#f7e36d", pants:"#355da8", pool:[19,20,21,16]},
    bug:{label:"Bug Catcher", skin:"#f0c49c", hat:"#bedf56", shirt:"#7cc858", pants:"#504630", pool:[10,13,15,165,167]},
    lass:{label:"Lass", skin:"#f2c3a3", hat:"#e46aa8", shirt:"#f58fc2", pants:"#68426e", pool:[35,39,29,30,183]},
    hiker:{label:"Hiker", skin:"#d49a6a", hat:"#82613b", shirt:"#b8874f", pants:"#4a3a29", pool:[74,75,66,95,185]},
    swimmer:{label:"Swimmer", skin:"#edb68e", hat:"#3dcbe6", shirt:"#48d6f2", pants:"#164c9a", pool:[60,72,118,116,170,194]},
    sailor:{label:"Sailor", skin:"#f3c199", hat:"#f5f5f0", shirt:"#5d87d9", pants:"#23366e", pool:[98,90,86,183]},
    biker:{label:"Biker", skin:"#c98b69", hat:"#222", shirt:"#5b5b66", pants:"#111", pool:[88,109,110,23,24]},
    rocket:{label:"Rocket", skin:"#d3a081", hat:"#111", shirt:"#333", pants:"#111", pool:[23,24,41,42,109,198]},
    scientist:{label:"Scientist", skin:"#e9bd95", hat:"#e5e5e5", shirt:"#f5f5ef", pants:"#5a5a6a", pool:[81,82,100,101,137]},
    psychic:{label:"Psychic", skin:"#e7b88f", hat:"#6335a8", shirt:"#825edb", pants:"#39225d", pool:[63,64,96,97,177,200]},
    ace:{label:"Ace Trainer", skin:"#e6b690", hat:"#d24b4b", shirt:"#4b7ed2", pants:"#252a36", pool:[58,64,123,125,126,227]},
    beauty:{label:"Beauty", skin:"#f0bc98", hat:"#f8d25c", shirt:"#f087ba", pants:"#744778", pool:[37,43,114,133,196]},
    gentleman:{label:"Gentleman", skin:"#d9a078", hat:"#2b2b2b", shirt:"#dfd8c0", pants:"#2d2d2d", pool:[52,58,133,203,234]},
    rival:{label:"Rival", skin:"#eabb93", hat:"#d64141", shirt:"#f06050", pants:"#315c9d", pool:[5,8,2,156,159,153,64,93]},
    leader:{label:"Gym Leader", skin:"#e7b48b", hat:"#f7d84a", shirt:"#ec6d41", pants:"#423768", pool:[95,121,26,45,94,65,59,230]},
    elite:{label:"Elite Four", skin:"#dfad8a", hat:"#5f477b", shirt:"#31344f", pants:"#141820", pool:[178,169,68,197,149]},
    champion:{label:"Champion", skin:"#efbf98", hat:"#e73535", shirt:"#f5d248", pants:"#2a3e78", pool:[149,130,6,142,248]}
  };

  const LEADERS = {
    kanto: [
      {name:"Brock", badge:"Boulder", type:"rock", cls:"leader", team:[74,95]}, {name:"Misty", badge:"Cascade", type:"water", cls:"leader", team:[120,121]},
      {name:"Lt. Surge", badge:"Thunder", type:"electric", cls:"leader", team:[100,25,26]}, {name:"Erika", badge:"Rainbow", type:"grass", cls:"leader", team:[71,114,45]},
      {name:"Koga", badge:"Soul", type:"poison", cls:"leader", team:[49,89,110]}, {name:"Sabrina", badge:"Marsh", type:"psychic", cls:"leader", team:[64,122,65]},
      {name:"Blaine", badge:"Volcano", type:"fire", cls:"leader", team:[58,77,78,59]}, {name:"Giovanni", badge:"Earth", type:"ground", cls:"leader", team:[111,51,31,34]}
    ],
    johto: [
      {name:"Falkner", badge:"Zephyr", type:"flying", cls:"leader", team:[16,17]}, {name:"Bugsy", badge:"Hive", type:"bug", cls:"leader", team:[123,11,14]},
      {name:"Whitney", badge:"Plain", type:"normal", cls:"leader", team:[35,241]}, {name:"Morty", badge:"Fog", type:"ghost", cls:"leader", team:[92,93,94]},
      {name:"Chuck", badge:"Storm", type:"fighting", cls:"leader", team:[57,62]}, {name:"Jasmine", badge:"Mineral", type:"steel", cls:"leader", team:[81,208]},
      {name:"Pryce", badge:"Glacier", type:"ice", cls:"leader", team:[86,87,221]}, {name:"Clair", badge:"Rising", type:"dragon", cls:"leader", team:[148,148,230]}
    ]
  };
  const ELITE = {
    kanto:[{name:"Lorelei", cls:"elite", team:[87,91,80,124,131]}, {name:"Bruno", cls:"elite", team:[95,107,106,95,68]}, {name:"Agatha", cls:"elite", team:[94,42,93,24,94]}, {name:"Lance", cls:"elite", team:[130,148,148,142,149]}, {name:"Champion", cls:"champion", team:[18,65,112,59,103,9]}],
    johto:[{name:"Will", cls:"elite", team:[178,103,80,124,178]}, {name:"Koga", cls:"elite", team:[168,205,89,49,169]}, {name:"Bruno", cls:"elite", team:[237,95,107,106,68]}, {name:"Karen", cls:"elite", team:[197,45,94,198,229]}, {name:"Lance", cls:"champion", team:[130,149,149,6,142,149]}]
  };

  const POOLS = {
    kantoRoute:[16,19,21,23,25,27,29,32,39,43,46,52,54,56,58,69,77,84],
    kantoForest:[10,11,12,13,14,15,16,25,43,44,46,48,49],
    kantoCave:[35,41,42,46,50,51,66,74,75,95,104,109],
    kantoWater:[60,72,73,79,86,90,98,99,116,117,118,119,120,129,130],
    kantoCity:[52,54,63,81,96,100,102,109,113,122,133],
    kantoRare:[83,108,113,115,123,124,125,126,127,128,131,132,137,142,143,147],
    johtoRoute:[16,19,21,41,152,155,158,161,163,165,167,179,183,187,190,191,194,206,209,216,231],
    johtoForest:[10,13,43,46,48,123,152,165,167,187,190,191,193,204,214],
    johtoCave:[41,42,50,51,66,74,75,95,109,173,174,185,194,200,202,206,213,216,220,246],
    johtoWater:[60,72,79,90,98,116,118,129,170,171,183,186,194,211,222,223,226,230],
    johtoCity:[52,63,81,88,96,133,172,175,177,190,203,209,234,235,241],
    johtoRare:[185,196,197,200,201,212,214,215,227,228,234,238,239,240,243,244,245,246]
  };

  const KANTO = [
    L("pallet","Pallet Town","city","kantoCity"), L("r1","Route 1","route","kantoRoute"), L("viridian","Viridian City","city","kantoCity"), L("r2","Route 2","route","kantoRoute"), L("vforest","Viridian Forest","forest","kantoForest"),
    G("pewter","Pewter City Gym","city",0), L("r3","Route 3","route","kantoRoute"), L("mtmoon","Mt. Moon","cave","kantoCave"), L("r4","Route 4","route","kantoRoute"), G("cerulean","Cerulean City Gym","city",1),
    L("r24","Nugget Bridge / Route 24","route","kantoRoute"), L("r25","Route 25","route","kantoRoute"), L("r5","Route 5","route","kantoRoute"), L("r6","Route 6","route","kantoRoute"), G("vermilion","Vermilion City Gym","city",2),
    L("r11","Route 11","route","kantoRoute"), L("diglett","Diglett's Cave","cave","kantoCave",[50,51]), L("r9","Route 9","route","kantoRoute"), L("rocktunnel","Rock Tunnel","cave","kantoCave"), L("lavender","Lavender Town","tower","kantoCity",[92,93,104,105,41]),
    L("r8","Route 8","route","kantoRoute"), G("celadon","Celadon City Gym","city",3), L("cycling","Cycling Road Routes 16-18","route","kantoRoute",[19,20,21,22,84,85,109,110]), L("safari","Safari Zone","forest","kantoRare"), G("fuchsia","Fuchsia City Gym","city",4),
    L("saffron","Saffron City Gym","city","kantoCity",[63,64,96,97,122]), G("saffronGym","Saffron Gym Challenge","city",5), L("r12","Route 12","water","kantoWater"), L("r13_15","Routes 13-15","route","kantoRoute"), L("seafoam","Seafoam Islands","water","kantoWater",[86,87,90,91,98,99,120,121,144]),
    L("cinnabar","Cinnabar Island","water","kantoWater"), L("mansion","Pokémon Mansion","cave","kantoCave",[37,58,77,88,109,126,132]), G("blaine","Cinnabar Gym","city",6), L("r21","Route 21","water","kantoWater"), G("viridianGym","Viridian Gym","city",7),
    L("r22","Route 22","route","kantoRoute"), L("r23","Route 23","mountain","kantoRoute"), L("victory","Victory Road","cave","kantoCave",[74,75,95,105,111,112,146,147,148]), E("indigo","Indigo Plateau","city")
  ];
  const JOHTO = [
    L("newbark","New Bark Town","city","johtoCity"), L("r29","Route 29","route","johtoRoute"), L("cherrygrove","Cherrygrove City","city","johtoCity"), L("r30","Route 30","route","johtoRoute"), L("r31","Route 31 / Dark Cave","cave","johtoCave"),
    G("violet","Violet City Gym","city",0,"johto"), L("sprout","Sprout Tower","tower","johtoCity",[19,92,163,69]), L("r32","Route 32","route","johtoRoute"), L("union","Union Cave","cave","johtoCave"), G("azalea","Azalea Town Gym","forest",1,"johto"),
    L("ilex","Ilex Forest","forest","johtoForest"), L("r34","Route 34","route","johtoRoute"), G("goldenrod","Goldenrod City Gym","city",2,"johto"), L("r35","Route 35","route","johtoRoute"), L("national","National Park","forest","johtoForest"),
    L("r36","Route 36","route","johtoRoute",[16,17,39,43,185,191,193]), G("ecruteak","Ecruteak City Gym","tower",3,"johto"), L("burned","Burned Tower","tower","johtoCave",[19,20,41,42,92,93,109,110,200]), L("r38","Route 38","route","johtoRoute"), L("r39","Route 39","route","johtoRoute"),
    G("olivine","Olivine City Gym","water",5,"johto"), L("lighthouse","Glitter Lighthouse","tower","johtoWater",[170,171,179,180,181,120]), L("r40","Route 40","water","johtoWater"), L("whirl","Whirl Islands","water","johtoWater",[72,73,86,87,98,99,116,117,170,171,249]), G("cianwood","Cianwood Gym","water",4,"johto"),
    L("r42","Route 42","route","johtoRoute"), L("mtmortar","Mt. Mortar","cave","johtoCave"), G("mahogany","Mahogany Gym","city",6,"johto"), L("lake","Lake of Rage","water","johtoWater",[129,130,183,184,193]), L("rocket","Rocket Hideout","cave","johtoCave",[19,20,23,24,41,42,88,89,109,110,198]),
    L("icepath","Ice Path","cave","johtoCave",[41,42,124,215,220,221,238,225]), G("blackthorn","Blackthorn Gym","mountain",7,"johto"), L("dragonsden","Dragon's Den","water","johtoWater",[60,61,129,130,147,148,230]), L("r45","Route 45","mountain","johtoCave"), L("r46","Route 46","mountain","johtoRoute"),
    L("victoryj","Victory Road","cave","johtoCave",[42,74,75,95,217,221,227,246,247]), E("indigoj","Indigo Plateau","city","johto")
  ];
  function L(id,name,theme,pool,custom){ return {id,name,theme,pool,custom}; }
  function G(id,name,theme,leaderIndex,region="kanto"){ return {id,name,theme,pool:region==="johto"?"johtoCity":"kantoCity", gym:LEADERS[region][leaderIndex]}; }
  function E(id,name,theme,region="kanto"){ return {id,name,theme,pool:region==="johto"?"johtoRare":"kantoRare", elite:true}; }

  let state=null, battle=null, selectedSwap=null;
  const $=s=>document.querySelector(s); const $$=s=>Array.from(document.querySelectorAll(s));
  const els={boot:$("#boot"), app:$("#app"), start:$("#startScreen"), shell:$("#gameShell"), starterChoices:$("#starterChoices"), continueSave:$("#continueSave"), teamList:$("#teamList"), bagList:$("#bagList"), badgeGrid:$("#badgeGrid"), nodeLayer:$("#nodeLayer"), overlay:$("#routeOverlay"), message:$("#message"), modal:$("#modal"), modalContent:$("#modalContent"), closeModal:$("#closeModal"), stageTitle:$("#stageTitle"), stageSubtitle:$("#stageSubtitle"), modeLabel:$("#modeLabel"), moneyLabel:$("#moneyLabel"), winsLabel:$("#winsLabel"), canvas:$("#mapCanvas"), player:$("#playerMarker")};

  document.addEventListener("DOMContentLoaded", boot);
  function boot(){ bindEvents(); drawStarterChoices("johto"); if(localStorage.getItem(SAVE_KEY)) els.continueSave.classList.remove("hidden"); setTimeout(()=>{els.boot.classList.add("hidden");els.app.classList.remove("hidden");els.start.classList.remove("hidden");},250); }
  function bindEvents(){
    $$('[data-region]').forEach(b=>b.addEventListener('click',()=>{$$('[data-region]').forEach(x=>x.classList.remove('active')); b.classList.add('active'); drawStarterChoices(b.dataset.region)}));
    $$('[data-mode]').forEach(b=>b.addEventListener('click',()=>{$$('[data-mode]').forEach(x=>x.classList.remove('active')); b.classList.add('active')}));
    els.continueSave.addEventListener('click',loadLocalSave); $('#importSaveHome').addEventListener('click',showImportSave); els.closeModal.addEventListener('click',()=>{if(!battle) closeModal()}); els.modal.addEventListener('click',e=>{if(e.target===els.modal&&!battle)closeModal()});
    $('#btnPokedex').addEventListener('click',showPokedex); $('#btnSave').addEventListener('click',showSaveCode); $('#btnAchievements').addEventListener('click',showAchievements); $('#btnTower').addEventListener('click',startTower); $('#btnReset').addEventListener('click',resetRun); $('#btnStageMap').addEventListener('click',()=>showStageInfo());
  }
  function drawStarterChoices(region){ els.starterChoices.innerHTML=''; STARTERS[region].forEach(id=>{const b=document.createElement('button'); b.className='starter-card'; b.innerHTML=`<img src="${SPRITE_FRONT(id)}" onerror="this.src='${SPRITE_FALLBACK(id)}'" alt=""><b>${nameOf(id)}</b><small>#${pad(id)}</small>`; b.onclick=()=>startRun(region,id); els.starterChoices.appendChild(b)}); }
  async function startRun(region,starterId){ const mode=$('[data-mode].active')?.dataset.mode||'normal'; const player=($('#playerName').value||'BRUNO').trim().toUpperCase().slice(0,14); state=defaultState(player,region,mode); state.team.push(createPokemon(starterId,5,true)); state.caught[starterId]=true; state.discovered[starterId]=true; enterGame(); showMessage(`Você começou por ${region.toUpperCase()}. Rotas e cidades mudam conforme a jornada.`); saveLocal(); }
  function defaultState(playerName,region,mode){ return {version:VERSION,playerName,region,mode,money:600,stageIndex:0,currentNode:'start',cleared:['start'],available:['a','b'],team:[],box:[],bag:{potion:3,superPotion:0,revive:1,rareCandy:0,pokeball:6,greatball:0,escapeRope:1},badges:[],discovered:{},caught:{},defeated:{},stats:{wins:0,losses:0,captures:0,wildBattles:0,trainerBattles:0,items:0,stageClears:0,tower:0,champion:false},log:[]}; }
  function enterGame(){ els.start.classList.add('hidden'); els.shell.classList.remove('hidden'); drawStage(); render(); }
  function campaign(){ return state?.region==='kanto'?KANTO:JOHTO; }
  function stage(){ return campaign()[state.stageIndex] || campaign()[campaign().length-1]; }
  function stageLevel(){ return Math.max(3,5+Math.floor(state.stageIndex*1.25)+state.badges.length*2); }

  function stageNodes(s=stage()){
    const base = [
      {id:'start',x:270,y:842,kind:'start',label:'Start',next:['a','b']},
      {id:'a',x:135,y:735,kind:themeFirst(s),label:labelKind(themeFirst(s)),next:['c','d']},
      {id:'b',x:405,y:735,kind:'capture',label:'Poké Ball',next:['d','e']},
      {id:'c',x:96,y:596,kind:'item',label:'Item Found',next:['f']},
      {id:'d',x:270,y:596,kind:'trainer',label:trainerFor(s).label,next:['f','g']},
      {id:'e',x:444,y:596,kind:citySpecial(s),label:labelKind(citySpecial(s)),next:['g']},
      {id:'f',x:172,y:438,kind:themeSecond(s),label:labelKind(themeSecond(s)),next:['h']},
      {id:'g',x:368,y:438,kind:s.gym?'gym':(s.elite?'elite':'question'),label:s.gym?s.gym.name:(s.elite?'Elite Four':'Random Event'),next:['h']},
      {id:'h',x:270,y:265,kind:'exit',label:state.stageIndex>=campaign().length-1?'Champion':'Next Area',next:[]}
    ];
    if(s.theme==='city') { base[1].kind='heal'; base[1].label='Pokémon Center'; base[2].kind='shop'; base[2].label='Mart'; base[4].kind=s.gym?'gym':'trainer'; base[4].label=s.gym?s.gym.name:trainerFor(s).label; base[5].kind='question'; base[5].label='City Event'; }
    if(s.theme==='water'){ base[1].x=95; base[2].x=445; base[3].kind='battle'; base[3].label='Surf Battle'; base[5].kind='trainer'; base[5].label='Swimmer'; }
    if(s.theme==='cave'||s.theme==='tower'){ base[1].kind='battle'; base[2].kind='item'; base[5].kind='trainer'; base[6].kind='capture'; }
    if(s.elite){ base[1].kind='heal'; base[2].kind='item'; base[4].kind='elite'; base[4].label='Elite Four'; base[6].kind='elite'; base[6].label='Elite Four'; base[7].kind='champion'; base[7].label='Champion'; base[8].label='Hall of Fame'; }
    return base;
  }
  function themeFirst(s){ if(s.theme==='forest')return 'capture'; if(s.theme==='cave')return 'battle'; if(s.theme==='water')return 'battle'; if(s.theme==='mountain')return 'trainer'; return 'battle'; }
  function themeSecond(s){ if(s.theme==='forest')return 'trainer'; if(s.theme==='cave')return 'battle'; if(s.theme==='water')return 'capture'; if(s.theme==='mountain')return 'battle'; return 'battle'; }
  function citySpecial(s){ if(s.theme==='city')return 'shop'; if(s.theme==='forest')return 'question'; if(s.theme==='water')return 'trainer'; return 'item'; }
  function labelKind(k){ return {battle:'Wild Battle',capture:'Poké Ball',trainer:'Trainer',item:'Item Found',heal:'Heal',shop:'Mart',question:'Random Event',gym:'Gym',elite:'Elite Four',champion:'Champion',exit:'Next Area'}[k]||k; }
  function trainerFor(s){
    const map={forest:'bug',cave:'hiker',water:'swimmer',tower:'psychic',mountain:'ace',city:'gentleman',route:'youngster'};
    const cls=map[s.theme]||'youngster'; return TRAINER_CLASSES[cls];
  }

  function render(){ if(!state)return; renderTeam(); renderBag(); renderBadges(); renderNodes(); const s=stage(); els.stageTitle.textContent=s.name; els.stageSubtitle.textContent=`${state.region.toUpperCase()} • ${s.theme.toUpperCase()} • ${state.stageIndex+1}/${campaign().length}`; els.modeLabel.textContent=state.mode; els.moneyLabel.textContent=state.money; els.winsLabel.textContent=state.stats.wins; }
  function renderTeam(){ els.teamList.innerHTML=''; state.team.forEach((p,i)=>{const pct=Math.max(0,Math.round(p.hp/p.maxHp*100)); const d=document.createElement('div'); d.className=`team-card ${p.hp<=0?'fainted':''} ${selectedSwap===i?'active':''}`; d.innerHTML=`<img src="${p.sprite}" onerror="this.src='${SPRITE_FALLBACK(p.id)}'"><span class="name">${p.name}</span><span class="level">Lv${p.level}</span><div class="hpbar ${pct<25?'low':pct<55?'mid':''}"><span style="width:${pct}%"></span></div><small>${Math.max(0,p.hp)}/${p.maxHp}</small>`; d.onclick=()=>swapTeam(i); els.teamList.appendChild(d)}); if(!state.team.length)els.teamList.innerHTML='<p>Team empty</p>'; }
  function swapTeam(i){ if(selectedSwap===null){selectedSwap=i;renderTeam();return} if(selectedSwap!==i){[state.team[selectedSwap],state.team[i]]=[state.team[i],state.team[selectedSwap]]; saveLocal();} selectedSwap=null; renderTeam(); }
  function renderBag(){ const lines=Object.entries(state.bag).filter(([,n])=>n>0).map(([k,n])=>`<div class="bag-item"><span>${ITEMS[k]?.name||k}</span><b>x${n}</b></div>`); els.bagList.innerHTML=lines.join('')||'<p>Bag empty</p>'; }
  function renderBadges(){ els.badgeGrid.innerHTML=''; const total=Math.max(16,state.badges.length); for(let i=0;i<total;i++){const b=state.badges[i]; const d=document.createElement('div'); d.className='badge '+(b?'owned':''); d.title=b||'Empty badge slot'; d.innerHTML=b?`<span>${b}</span>`:''; els.badgeGrid.appendChild(d)} }
  function renderNodes(){
    const nodes=stageNodes(); els.nodeLayer.innerHTML=''; els.overlay.innerHTML='';
    const by=Object.fromEntries(nodes.map(n=>[n.id,n])); nodes.forEach(n=>{(n.next||[]).forEach(to=>{const m=by[to]; if(!m)return; const line=document.createElementNS('http://www.w3.org/2000/svg','line'); line.setAttribute('x1',n.x);line.setAttribute('y1',n.y);line.setAttribute('x2',m.x);line.setAttribute('y2',m.y); line.setAttribute('class','route-line '+(state.cleared.includes(n.id)&&state.cleared.includes(m.id)?'done':'')); els.overlay.appendChild(line);});});
    nodes.forEach(n=>{ const btn=document.createElement('button'); const available=state.available.includes(n.id); const cleared=state.cleared.includes(n.id); btn.className=`node ${available?'available':''} ${cleared?'cleared':''} ${(!available&&!cleared)?'locked':''}`; btn.style.left=n.x+'px'; btn.style.top=n.y+'px'; btn.innerHTML=`<span class="node-icon">${iconFor(n)}</span><span class="node-label">${n.label}</span>`; btn.onclick=()=>available&&handleNode(n); els.nodeLayer.appendChild(btn); });
    const cur=by[state.currentNode]||by.start; els.player.style.left=(cur.x)+'px'; els.player.style.top=(cur.y+8)+'px';
  }
  function iconFor(n){ if(n.kind==='battle')return '<span class="grass-icon"></span>'; if(n.kind==='capture')return '<span class="ball-icon"></span>'; if(n.kind==='item')return '<span class="item-icon"></span>'; if(n.kind==='heal')return '<span class="heal-icon"></span>'; if(n.kind==='shop')return '<span class="shop-icon"></span>'; if(n.kind==='gym'||n.kind==='elite'||n.kind==='champion')return npcSprite(n.kind==='champion'?'champion':n.kind==='elite'?'elite':'leader','small'); if(n.kind==='trainer')return npcSprite(classKeyForStage(stage()),'small'); if(n.kind==='exit')return '<span class="exit-icon"></span>'; if(n.kind==='question')return '<span class="quest-icon"></span>'; return ''; }
  function classKeyForStage(s){ return {forest:'bug',cave:'hiker',water:'swimmer',tower:'psychic',mountain:'ace',city:'gentleman',route:'youngster'}[s.theme]||'youngster'; }
  function npcSprite(key,size='small'){ const t=TRAINER_CLASSES[key]||TRAINER_CLASSES.youngster; return `<span class="npc ${size}" style="--skin:${t.skin};--hat:${t.hat};--shirt:${t.shirt};--pants:${t.pants}"><i class="hat"></i><i class="head"></i><i class="face"></i><i class="body"></i><i class="legs"></i></span>`; }

  function handleNode(n){ state.currentNode=n.id; saveProgress(n); render(); const kind=n.kind; if(kind==='battle')return startWildBattle(); if(kind==='capture')return startCapture(); if(kind==='trainer')return startTrainerBattle(); if(kind==='item')return findItem(); if(kind==='heal')return healParty(); if(kind==='shop')return openShop(); if(kind==='question')return randomEvent(); if(kind==='gym')return startGymBattle(); if(kind==='elite')return startEliteBattle(false); if(kind==='champion')return startEliteBattle(true); if(kind==='exit')return advanceStage(); }
  function saveProgress(n){ if(!state.cleared.includes(n.id)) state.cleared.push(n.id); const nodes=stageNodes(); const next=(n.next||[]).filter(Boolean); state.available=Array.from(new Set([...state.available.filter(id=>!state.cleared.includes(id)),...next])); state.available=state.available.filter(id=>nodes.some(n=>n.id===id)); saveLocal(); }
  function advanceStage(){ if(state.stageIndex>=campaign().length-1){ state.stats.champion=true; saveLocal(); showHallOfFame(); return; } state.stageIndex++; state.currentNode='start'; state.cleared=['start']; state.available=['a','b']; state.stats.stageClears++; drawStage(); render(); showMessage(`Você chegou em ${stage().name}. O mapa, NPCs e encontros mudaram para esta área.`); saveLocal(); }

  function drawStage(){ const canvas=els.canvas, ctx=canvas.getContext('2d'), s=stage(); const seed=hash(`${s.id}-${s.name}`); drawBackground(ctx,s,seed); }
  function drawBackground(ctx,s,seed){ const W=540,H=890, rnd=mulberry(seed); ctx.clearRect(0,0,W,H); const theme=s.theme; const C={grass:'#65d69b',grass2:'#53c98b',tree:'#2f8a40',tree2:'#1e6c38',path:'#d6ba72',city:'#b8b9b0',road:'#ded6b7',water:'#59bde9',water2:'#3d8ccd',cave:'#6d655c',cave2:'#49443d',sand:'#e6cf8d',roof:'#2bb7b6',rock:'#8b8379'};
    fill(ctx,0,0,W,H, theme==='water'?C.water:theme==='cave'||theme==='tower'?C.cave:theme==='city'?C.city:C.grass);
    if(theme==='route'||theme==='forest'||theme==='mountain'){ drawPath(ctx,270,850,270,50,C.path,54,seed); drawTrees(ctx,theme,seed); scatter(ctx,theme==='mountain'?C.rock:C.grass2,theme==='mountain'?35:65,seed); if(theme==='mountain')drawRocks(ctx,seed); }
    if(theme==='forest'){ drawPath(ctx,110,850,430,50,C.path,42,seed+3); drawTrees(ctx,'dense',seed+5); }
    if(theme==='city'){ drawCity(ctx,s,seed); }
    if(theme==='cave'||theme==='tower'){ drawCave(ctx,s,seed); }
    if(theme==='water'){ drawWater(ctx,s,seed); }
    drawStageHeaderBuilding(ctx,s,theme);
    // pixel grain
    for(let i=0;i<550;i++){ const x=Math.floor(rnd()*W), y=Math.floor(rnd()*H); ctx.fillStyle=`rgba(255,255,255,${rnd()*.11})`; ctx.fillRect(x,y,2,2); }
  }
  function fill(ctx,x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(x,y,w,h)}
  function drawPath(ctx,x1,y1,x2,y2,c,w,seed){ const rnd=mulberry(seed); ctx.strokeStyle=c; ctx.lineWidth=w; ctx.lineCap='round'; ctx.beginPath(); ctx.moveTo(x1,y1); for(let i=1;i<=7;i++){ const t=i/7; const x=x1+(x2-x1)*t+(rnd()-.5)*120; const y=y1+(y2-y1)*t; ctx.lineTo(x,y);} ctx.stroke(); ctx.strokeStyle='#a98852'; ctx.lineWidth=3; ctx.setLineDash([8,8]); ctx.stroke(); ctx.setLineDash([]); }
  function drawTrees(ctx,kind,seed){ const rnd=mulberry(seed); const count=kind==='dense'?120:kind==='mountain'?25:80; for(let i=0;i<count;i++){ const side=rnd()<.5?rnd()*120:420+rnd()*120; const y=rnd()*890; tree(ctx,side,y,kind==='dense'); } }
  function tree(ctx,x,y,big=false){ fill(ctx,x-10,y+12,20,22,'#5c4129'); ctx.fillStyle='#2b783e'; ctx.beginPath(); ctx.arc(x,y, big?30:24,0,7); ctx.fill(); ctx.fillStyle='#3d9a4b'; ctx.beginPath(); ctx.arc(x-8,y-8,big?22:17,0,7); ctx.arc(x+10,y-5,big?22:17,0,7); ctx.fill(); }
  function scatter(ctx,c,count,seed){ const rnd=mulberry(seed+9); ctx.fillStyle=c; for(let i=0;i<count;i++){ const x=rnd()*540,y=rnd()*890; ctx.fillRect(x,y,8+rnd()*10,4+rnd()*8); } }
  function drawRocks(ctx,seed){ const rnd=mulberry(seed+8); for(let i=0;i<45;i++){ const x=rnd()*540,y=rnd()*890; fill(ctx,x,y,18,12,'#8a8377'); fill(ctx,x+3,y-3,10,5,'#aca59a'); } }
  function drawCity(ctx,s,seed){ fill(ctx,0,0,540,890,'#aac1a7'); fill(ctx,50,0,70,890,'#d9d0b8'); fill(ctx,420,0,70,890,'#d9d0b8'); fill(ctx,0,380,540,70,'#d9d0b8'); fill(ctx,235,0,70,890,'#d9d0b8'); for(let i=0;i<5;i++) house(ctx,80+(i%2)*330,95+i*130,i%2?'#d94f45':'#39a0d8'); house(ctx,230,220,'#2bb7b6'); house(ctx,230,500,'#e35555'); if(s.gym) gym(ctx,205,72,s.gym.type); }
  function house(ctx,x,y,roof){ fill(ctx,x,y+30,96,72,'#f2dfba'); fill(ctx,x-8,y+20,112,24,roof); fill(ctx,x+38,y+65,20,37,'#6b4638'); fill(ctx,x+12,y+50,22,18,'#93d7e4'); fill(ctx,x+62,y+50,22,18,'#93d7e4'); }
  function gym(ctx,x,y,type){ fill(ctx,x,y+45,130,94,'#d7d9df'); fill(ctx,x-12,y+26,154,32,'#6d7587'); fill(ctx,x+45,y+78,40,61,'#33394c'); ctx.fillStyle='#fff'; ctx.font='16px monospace'; ctx.fillText('GYM',x+45,y+70); }
  function drawCave(ctx,s,seed){ const rnd=mulberry(seed+20); fill(ctx,0,0,540,890,s.theme==='tower'?'#595062':'#5d564e'); drawPath(ctx,270,850,270,45,s.theme==='tower'?'#8b7694':'#8d806c',66,seed); for(let i=0;i<130;i++){ const x=rnd()*540,y=rnd()*890; fill(ctx,x,y,24+rnd()*20,12+rnd()*15,rnd()<.5?'#3f3a35':'#756d63'); } if(s.theme==='tower'){ for(let y=80;y<780;y+=120){ fill(ctx,100,y,340,16,'#4a354d'); fill(ctx,112,y-10,18,36,'#2e2534'); fill(ctx,410,y-10,18,36,'#2e2534'); } } }
  function drawWater(ctx,s,seed){ const rnd=mulberry(seed+30); fill(ctx,0,0,540,890,'#53bfe9'); for(let y=0;y<890;y+=38){ ctx.strokeStyle='rgba(255,255,255,.45)'; ctx.lineWidth=3; ctx.beginPath(); for(let x=0;x<560;x+=40){ ctx.lineTo(x,y+Math.sin((x+y)/60)*8); } ctx.stroke(); } fill(ctx,190,740,160,110,'#e1ca8a'); fill(ctx,205,750,130,88,'#7cc16a'); fill(ctx,80,120,120,90,'#e1ca8a'); fill(ctx,95,132,90,66,'#79ba65'); fill(ctx,380,420,120,110,'#e1ca8a'); fill(ctx,395,432,90,82,'#79ba65'); drawPath(ctx,270,850,270,50,'#c99f6a',35,seed+4); }
  function drawStageHeaderBuilding(ctx,s,theme){ if(theme==='route'||theme==='forest'||theme==='mountain'){ house(ctx,204,15,theme==='mountain'?'#888':'#25b7b5'); } if(theme==='water'){ house(ctx,205,40,'#25b7b5'); } if(theme==='cave'){ fill(ctx,190,25,160,92,'#332f2b'); ctx.fillStyle='#111'; ctx.beginPath(); ctx.arc(270,118,70,Math.PI,0); ctx.fill(); } }

  function startWildBattle(){ const mon=randomEncounter(); state.stats.wildBattles++; startBattle({kind:'wild', title:'Wild Battle', enemyTeam:[mon], trainer:null, canRun:true, reward:Math.round(mon.level*35)}); }
  function startTrainerBattle(){ const s=stage(), cls=classKeyForStage(s), t=TRAINER_CLASSES[cls]; const team=makeTrainerTeam(t.pool,2+Math.floor(state.stageIndex/12),stageLevel()); startBattle({kind:'trainer', title:t.label, enemyTeam:team, trainer:{name:t.label, cls}, reward:200+stageLevel()*25}); }
  function startGymBattle(){ const g=stage().gym; const team=g.team.map((id,i)=>createPokemon(id,stageLevel()+2+i)); startBattle({kind:'gym', title:`Gym Leader ${g.name}`, enemyTeam:team, trainer:{name:g.name, cls:'leader'}, reward:1000+stageLevel()*80, badge:g.badge}); }
  function startEliteBattle(champ){ const list=ELITE[state.region]; const idx= champ?list.length-1 : Math.min(Math.floor(state.stats.wins)%4,3); const e=list[idx]; const team=e.team.map((id,i)=>createPokemon(id,Math.max(42,stageLevel()+6+i))); startBattle({kind:champ?'champion':'elite', title:e.name, enemyTeam:team, trainer:{name:e.name, cls:e.cls}, reward:2500+stageLevel()*130, champion:champ}); }
  function startBattle(config){ const player=firstAlive(); if(!player){showMessage('Seu time está sem HP. Use cura ou reinicie.'); return;} battle={...config, enemyIndex:0, log:[config.title+' começou!']}; closeModal(false); drawBattle(); }
  function enemy(){ return battle.enemyTeam[battle.enemyIndex]; }
  function firstAlive(){ return state.team.find(p=>p.hp>0); }
  function drawBattle(){ const p=firstAlive(), e=enemy(); if(!p||!e){return finishBattle(false)}; const trainerHTML=battle.trainer?`<div>${npcSprite(battle.trainer.cls,'big')}<div class="trainer-title">${battle.trainer.name}</div></div>`:''; els.modalContent.innerHTML=`<h2>${battle.title}</h2><div class="battle-layout"><div class="battle-side"><div class="battle-name">${p.name} Lv${p.level}</div><img class="poke" src="${SPRITE_BACK(p.id)}" onerror="this.src='${p.sprite}'"><div class="hpbar ${p.hp/p.maxHp<.25?'low':p.hp/p.maxHp<.55?'mid':''}"><span style="width:${Math.max(0,p.hp/p.maxHp*100)}%"></span></div><p>${Math.max(0,p.hp)}/${p.maxHp} HP</p></div><div class="battle-side">${trainerHTML}<div class="battle-name">${e.name} Lv${e.level}</div><img class="poke" src="${e.sprite}" onerror="this.src='${SPRITE_FALLBACK(e.id)}'"><div>${e.types.map(t=>`<span class="type-pill">${t}</span>`).join('')}</div><div class="hpbar ${e.hp/e.maxHp<.25?'low':e.hp/e.maxHp<.55?'mid':''}"><span style="width:${Math.max(0,e.hp/e.maxHp*100)}%"></span></div><p>${Math.max(0,e.hp)}/${e.maxHp} HP</p></div></div><div class="battle-actions"><button id="atk1">${moveFor(p,0).name}</button><button id="atk2">${moveFor(p,1).name}</button><button id="usePotion">Use Potion</button>${battle.canRun?'<button id="runBattle">Run</button>':''}</div><div class="log-box">${battle.log.slice(-7).join('<br>')}</div>`; openModal(); $('#atk1').onclick=()=>playerAttack(0); $('#atk2').onclick=()=>playerAttack(1); $('#usePotion').onclick=()=>useBattlePotion(); const rb=$('#runBattle'); if(rb) rb.onclick=()=>{battle.log.push('Você fugiu da batalha.'); finishBattle(false,true)}; }
  function playerAttack(slot){ const p=firstAlive(), e=enemy(), mv=moveFor(p,slot); const dmg=damage(p,e,mv); e.hp=Math.max(0,e.hp-dmg); battle.log.push(`${p.name} usou ${mv.name}! ${dmg} dmg.`); if(e.hp<=0){ return enemyFainted(); } enemyAttack(); drawBattle(); }
  function enemyAttack(){ const p=firstAlive(), e=enemy(), mv=moveFor(e,Math.floor(Math.random()*2)); const dmg=damage(e,p,mv); p.hp=Math.max(0,p.hp-dmg); battle.log.push(`${e.name} usou ${mv.name}! ${dmg} dmg.`); if(p.hp<=0){ battle.log.push(`${p.name} fainted!`); if(!firstAlive()) return finishBattle(false); } }
  function enemyFainted(){ const p=firstAlive(), e=enemy(); battle.log.push(`${e.name} fainted!`); gainExp(p,e.level*18); state.defeated[e.id]=true; state.discovered[e.id]=true; battle.enemyIndex++; if(battle.enemyIndex>=battle.enemyTeam.length) return finishBattle(true); drawBattle(); }
  function finishBattle(win,ran=false){ if(win){ state.stats.wins++; state.money+=battle.reward||0; if(['trainer','gym','elite','champion'].includes(battle.kind)) state.stats.trainerBattles++; if(battle.badge && !state.badges.includes(battle.badge)) { state.badges.push(battle.badge); showMessage(`Badge Earned: ${battle.badge}!`); } else showMessage(`Vitória! Ganhou ¥${battle.reward||0}.`); if(battle.champion){state.stats.champion=true; setTimeout(showHallOfFame,500);} } else if(!ran){ state.stats.losses++; showMessage(state.mode==='nuzlocke'?'Derrota. No Nuzlocke, Pokémon derrotados ficam marcados.':'Derrota. Cure seu time no próximo Centro.'); }
    battle=null; saveLocal(); render(); closeModal(); }
  function damage(a,d,mv){ let base=Math.floor((a.level*0.8)+(a.atk*0.55)-(d.def*0.28)+10); base=Math.max(3,base); const mult=(EFFECT[mv.type]||{})[d.types[0]] ?? 1; const stab=a.types.includes(mv.type)?1.25:1; return Math.max(1,Math.floor(base*mult*stab*(0.85+Math.random()*0.3))); }
  function moveFor(p,slot){ const types=p.types.length?p.types:['normal']; const type=slot===0?types[0]:(types[1]||types[0]||'normal'); const arr=MOVE_POOL[type]||MOVE_POOL.normal; return {name:arr[Math.min(slot,arr.length-1)]||arr[0],type}; }
  function useBattlePotion(){ const key=state.bag.superPotion>0?'superPotion':state.bag.potion>0?'potion':null; if(!key){battle.log.push('Sem Potion.'); return drawBattle();} const p=firstAlive(); state.bag[key]--; p.hp=Math.min(p.maxHp,p.hp+ITEMS[key].value); battle.log.push(`${ITEMS[key].name} curou ${p.name}.`); enemyAttack(); saveLocal(); drawBattle(); }
  function gainExp(p,amount){ p.exp=(p.exp||0)+amount; const need=p.level*28; if(p.exp>=need){ p.exp-=need; p.level++; p.maxHp+=3+Math.floor(Math.random()*3); p.atk+=2; p.def+=2; p.spd+=1; p.hp=p.maxHp; battle?.log.push(`${p.name} subiu para Lv${p.level}!`); evolveIfReady(p); } }
  function evolveIfReady(p){ const evo=EVOS[p.id]; if(evo && p.level>=evo[0]){ const old=p.name; p.id=evo[1]; p.name=nameOf(p.id); p.sprite=SPRITE_FRONT(p.id); p.types=typesOf(p.id); state.discovered[p.id]=true; state.caught[p.id]=true; battle?.log.push(`${old} evoluiu para ${p.name}!`); } }

  function startCapture(){ const mon=randomEncounter(); state.discovered[mon.id]=true; const chance=Math.min(.85,.38+(state.badges.length*.025)+(state.bag.greatball>0?.15:0)); const card=`<h2>Wild Pokemon Appeared</h2><div class="event-card"><img src="${mon.sprite}" onerror="this.src='${SPRITE_FALLBACK(mon.id)}'"><h3>${mon.name} Lv${mon.level}</h3><p>Este nó é de captura. Wild Battle continua sendo só batalha.</p><p>Chance estimada: ${Math.round(chance*100)}%</p><div class="battle-actions"><button id="throwBall">Throw Poké Ball</button><button id="leaveCatch">Leave</button></div></div>`; els.modalContent.innerHTML=card; openModal(); $('#leaveCatch').onclick=()=>{closeModal();showMessage(`${mon.name} fugiu.`)}; $('#throwBall').onclick=()=>{const ball=state.bag.greatball>0?'greatball':state.bag.pokeball>0?'pokeball':null; if(!ball){showMessage('Sem Poké Ball.'); closeModal(); return;} state.bag[ball]--; const ok=Math.random()<chance*ITEMS[ball].value; if(ok){ addPokemon(mon); state.caught[mon.id]=true; state.stats.captures++; showMessage(`${mon.name} capturado!`); } else showMessage(`${mon.name} escapou da Poké Ball.`); closeModal(); saveLocal(); render();}; }
  function addPokemon(mon){ if(state.team.length<6)state.team.push(mon); else state.box.push(mon); }
  function findItem(){ const keys=['potion','superPotion','pokeball','greatball','rareCandy','revive','escapeRope']; const k=keys[Math.floor(Math.random()*keys.length)]; const qty=k==='pokeball'?2:1; state.bag[k]=(state.bag[k]||0)+qty; state.stats.items++; showMessage(`Item Found: ${ITEMS[k].name} x${qty}.`); saveLocal(); render(); }
  function healParty(){ state.team.forEach(p=>p.hp=p.maxHp); showMessage('Pokémon Center: seu time foi curado.'); saveLocal(); render(); }
  function openShop(){ els.modalContent.innerHTML=`<h2>Mart</h2><p>Compre itens para próximas rotas.</p>${Object.entries(ITEMS).filter(([k])=>['potion','superPotion','pokeball','greatball','revive','escapeRope'].includes(k)).map(([k,it])=>`<div class="shop-row"><div><b>${it.name}</b><br><small>${it.desc}</small></div><button data-buy="${k}">¥${it.price}</button></div>`).join('')}`; openModal(); $$('[data-buy]').forEach(b=>b.onclick=()=>{const k=b.dataset.buy,it=ITEMS[k]; if(state.money<it.price)return toast('Dinheiro insuficiente.'); state.money-=it.price; state.bag[k]=(state.bag[k]||0)+1; render(); saveLocal(); toast(`${it.name} comprado.`);}); }
  function randomEvent(){ const r=Math.random(); if(r<.33)return findItem(); if(r<.66)return startTrainerBattle(); const mon=randomEncounter(true); els.modalContent.innerHTML=`<h2>Trade Offer</h2><p>Um NPC oferece ${mon.name}. Aceitar por ¥${200+mon.level*40}?</p><div class="event-card"><img src="${mon.sprite}"><h3>${mon.name} Lv${mon.level}</h3><button id="tradeYes">Accept</button></div>`; openModal(); $('#tradeYes').onclick=()=>{const price=200+mon.level*40; if(state.money<price)return toast('Dinheiro insuficiente.'); state.money-=price; addPokemon(mon); state.caught[mon.id]=true; state.discovered[mon.id]=true; closeModal(); showMessage(`Você recebeu ${mon.name}.`); saveLocal(); render();}; }

  function makeTrainerTeam(pool,count,lvl){ const arr=[]; for(let i=0;i<count;i++) arr.push(createPokemon(pool[Math.floor(Math.random()*pool.length)], lvl+i)); return arr; }
  function randomEncounter(rare=false){ const s=stage(); const pool=s.custom || POOLS[s.pool] || POOLS[state.region+'Route'] || POOLS.kantoRoute; let id=pool[Math.floor(Math.random()*pool.length)]; if(rare && Math.random()<.5){ const rp=POOLS[state.region+'Rare']; id=rp[Math.floor(Math.random()*rp.length)]; } return createPokemon(id, Math.max(2,stageLevel()+Math.floor(Math.random()*4)-1)); }
  function createPokemon(id,level,starter=false){ const types=typesOf(id); const hp=24+level*3+Math.floor(id%11); return {id,name:nameOf(id),level,exp:0,maxHp:hp,hp,atk:8+level*2+(id%7),def:7+level*2+(id%5),spd:7+level+(id%9),types,sprite:SPRITE_FRONT(id),starter}; }
  function typesOf(id){ return TYPE_FALLBACKS[id] || [TYPE_NAMES[id%TYPE_NAMES.length]]; }
  function nameOf(id){ return POKEMON_NAMES[id-1] || `Pokemon ${id}`; }
  function pad(id){ return String(id).padStart(3,'0'); }

  function showPokedex(){ const total=251; let html='<h2>Pokédex Gen I + II</h2><p>Mostra 251 Pokémon. Capturados e vistos são marcados pelo seu save.</p><div class="dex-grid">'; for(let id=1;id<=total;id++){const seen=state?.discovered?.[id]||state?.caught?.[id]; html+=`<div class="dex-card ${seen?'':'unknown'}"><img src="${SPRITE_FRONT(id)}" onerror="this.src='${SPRITE_FALLBACK(id)}'"><b>#${pad(id)}</b><br>${seen?nameOf(id):'????'}<br>${state?.caught?.[id]?'CAUGHT':' '}</div>`;} html+='</div>'; els.modalContent.innerHTML=html; openModal(); }
  function showSaveCode(){ const code=btoa(unescape(encodeURIComponent(JSON.stringify(state)))); els.modalContent.innerHTML=`<h2>Save Code</h2><p>Copie este código para importar depois.</p><textarea class="save-box" readonly>${code}</textarea><div class="battle-actions"><button id="copySave">Copy</button><button id="exportClose">Close</button></div>`; openModal(); $('#copySave').onclick=async()=>{try{await navigator.clipboard.writeText(code);toast('Código copiado.')}catch(e){toast('Copie manualmente.')}}; $('#exportClose').onclick=closeModal; }
  function showImportSave(){ els.modalContent.innerHTML=`<h2>Import Save Code</h2><textarea id="importBox" class="save-box" placeholder="Cole o Save Code aqui"></textarea><div class="battle-actions"><button id="doImport">Import</button></div>`; openModal(); $('#doImport').onclick=()=>{try{const data=JSON.parse(decodeURIComponent(escape(atob($('#importBox').value.trim())))); state=data; enterGame(); saveLocal(); closeModal();}catch(e){toast('Código inválido.')}}; }
  function showAchievements(){ const s=state?.stats||{}; els.modalContent.innerHTML=`<h2>Achievements</h2><ul><li>Vitórias: ${s.wins||0}</li><li>Capturas: ${s.captures||0}</li><li>Wild Battles: ${s.wildBattles||0}</li><li>Itens encontrados: ${s.items||0}</li><li>Badges: ${state?.badges?.length||0}</li><li>Áreas concluídas: ${s.stageClears||0}</li><li>Champion: ${s.champion?'Sim':'Não'}</li></ul>`; openModal(); }
  function showStageInfo(){ const s=stage(); const pool=s.custom || POOLS[s.pool] || []; els.modalContent.innerHTML=`<h2>${s.name}</h2><p class="stage-note">Tema do mapa: <b>${s.theme}</b>. Os nós, NPCs, encontros, cidade/rota/caverna/água e o sprite do treinador mudam de acordo com esta área.</p><p>Encontros possíveis:</p><div class="dex-grid">${pool.slice(0,24).map(id=>`<div class="dex-card"><img src="${SPRITE_FRONT(id)}"><b>#${pad(id)}</b><br>${nameOf(id)}</div>`).join('')}</div>`; openModal(); }
  function showHallOfFame(){ els.modalContent.innerHTML=`<h2>Hall of Fame</h2><p>${state.playerName} venceu a jornada em ${state.region.toUpperCase()}.</p><div class="event-grid">${state.team.map(p=>`<div class="event-card"><img src="${p.sprite}"><h3>${p.name}</h3><p>Lv${p.level}</p></div>`).join('')}</div>`; openModal(); }
  function startTower(){ const lvl=Math.max(20,stageLevel()+5+(state.stats.tower||0)*2); const team=makeTrainerTeam(POOLS[state.region+'Rare']||POOLS.kantoRare,3,lvl); state.stats.tower++; startBattle({kind:'trainer',title:`Battle Tower ${state.stats.tower}F`,enemyTeam:team,trainer:{name:'Tower Ace',cls:'ace'},reward:1500+lvl*40}); }
  function resetRun(){ if(confirm('Resetar todo o progresso local?')){localStorage.removeItem(SAVE_KEY); location.reload();} }
  function saveLocal(){ if(state)localStorage.setItem(SAVE_KEY,JSON.stringify(state)); }
  function loadLocalSave(){ try{state=JSON.parse(localStorage.getItem(SAVE_KEY)); enterGame(); showMessage('Save carregado.');}catch(e){toast('Não consegui carregar o save.');} }
  function openModal(){ els.modal.classList.remove('hidden'); }
  function closeModal(){ els.modal.classList.add('hidden'); if(!battle) els.modalContent.innerHTML=''; }
  function showMessage(msg){ els.message.textContent=msg; }
  function toast(msg){ const d=document.createElement('div'); d.className='toast'; d.textContent=msg; document.body.appendChild(d); setTimeout(()=>d.remove(),2200); }
  function hash(str){ let h=2166136261; for(let i=0;i<str.length;i++){ h^=str.charCodeAt(i); h=Math.imul(h,16777619);} return h>>>0; }
  function mulberry(a){ return function(){ let t=a+=0x6D2B79F5; t=Math.imul(t^t>>>15,t|1); t^=t+Math.imul(t^t>>>7,t|61); return ((t^t>>>14)>>>0)/4294967296; }; }

  // ===== V8 REMODEL: Kanto/Johto route-by-route, top-to-bottom run =====
  // This block intentionally overrides the earlier campaign/map functions.
  // The goal is not to ship copyrighted Game Boy map files, but to create
  // coherent fan-made pixel maps for each named route/city while keeping the
  // same event grammar as Pokelike.
  function R(id,name,theme,pool,custom,trainer,layout){ return {id,name,theme,pool,custom,trainer,layout}; }
  function RG(id,name,theme,leaderIndex,region="kanto",trainer,layout){ return {id,name,theme,pool:region==="johto"?"johtoCity":"kantoCity", gym:LEADERS[region][leaderIndex], trainer:trainer||"leader", layout}; }
  function RE(id,name,theme,region="kanto",custom,layout){ return {id,name,theme,pool:region==="johto"?"johtoRare":"kantoRare", elite:true, custom, layout}; }

  const KANTO_V8 = [
    R("pallet","Pallet Town","city","kantoCity",[16,19,21,54],"youngster","small-town"),
    R("r1","Route 1","route","kantoRoute",[16,19,20,21],"youngster","north-south-grass"),
    R("viridian","Viridian City","city","kantoCity",[19,21,25,54],"gentleman","city-garden"),
    R("r22","Route 22","mountain","kantoRoute",[19,21,29,32,56,66],"ace","rival-road"),
    R("r2","Route 2","route","kantoRoute",[10,13,16,19,21,25],"bug","forest-gate"),
    R("vforest","Viridian Forest","forest","kantoForest",[10,11,12,13,14,15,16,25],"bug","deep-forest"),
    RG("pewter","Pewter City Gym","city",0,"kanto","hiker","museum-city"),
    R("r3","Route 3","mountain","kantoRoute",[16,21,23,27,39,56],"lass","rocky-hills"),
    R("mtmoon","Mt. Moon","cave","kantoCave",[35,41,46,74,95],"hiker","moon-cave"),
    R("r4","Route 4","mountain","kantoRoute",[16,19,21,23,27,39,54],"hiker","east-cliffs"),
    RG("cerulean","Cerulean City Gym","water",1,"kanto","swimmer","canal-city"),
    R("r24","Route 24 / Nugget Bridge","water","kantoRoute",[10,13,16,43,54,63,69],"youngster","bridge"),
    R("r25","Route 25","route","kantoRoute",[16,19,21,43,54,63,69],"lass","cape-path"),
    R("r5","Route 5","route","kantoRoute",[16,19,43,52,63],"gentleman","urban-route"),
    R("underground","Underground Path","tower","kantoCity",[19,52,81,100],"scientist","tunnel"),
    R("r6","Route 6","route","kantoRoute",[16,19,43,52,63],"beauty","urban-route"),
    RG("vermilion","Vermilion City Gym","water",2,"kanto","sailor","harbor-city"),
    R("r11","Route 11","route","kantoRoute",[16,19,20,21,23,27,96,100],"gambler","fence-route"),
    R("diglett","Diglett's Cave","cave","kantoCave",[50,51],"hiker","diglett-cave"),
    R("r9","Route 9","mountain","kantoRoute",[19,21,23,27,56,66,74],"hiker","boulder-road"),
    R("r10","Route 10 / Power Plant","water","kantoRoute",[19,21,23,25,81,100,125,145],"scientist","power-plant"),
    R("rocktunnel","Rock Tunnel","cave","kantoCave",[41,42,66,74,75,95,104],"hiker","dark-tunnel"),
    R("lavender","Lavender Town / Pokémon Tower","tower","kantoCity",[41,92,93,104,105],"psychic","tower-town"),
    R("r8","Route 8","route","kantoRoute",[16,23,37,39,52,58,63],"lass","city-edge"),
    R("r7","Route 7","route","kantoRoute",[16,23,37,39,52,58,63],"beauty","short-city-route"),
    RG("celadon","Celadon City Gym","city",3,"kanto","beauty","big-city"),
    R("r16","Route 16","route","kantoRoute",[19,20,21,22,84,85,143],"biker","cycling-gate"),
    R("r17","Route 17 / Cycling Road","route","kantoRoute",[19,20,21,22,84,85,88,109],"biker","cycling-road"),
    R("r18","Route 18","route","kantoRoute",[19,20,21,22,84,85],"biker","cycling-exit"),
    RG("fuchsia","Fuchsia City Gym","forest",4,"kanto","biker","safari-city"),
    R("safari","Safari Zone","forest","kantoRare",[29,32,46,47,48,49,84,85,102,103,111,113,115,123,127,128,147],"ace","safari"),
    R("r15","Route 15","route","kantoRoute",[16,17,19,20,29,32,43,44,48],"lass","fence-route"),
    R("r14","Route 14","route","kantoRoute",[16,17,19,20,29,32,43,44,48],"birdkeeper","fence-route"),
    R("r13","Route 13","route","kantoRoute",[16,17,19,20,29,32,43,44,48,132],"beauty","maze-fence"),
    R("r12","Route 12 / Silence Bridge","water","kantoWater",[60,79,98,118,129,143],"fisher","dock-bridge"),
    RG("saffronGym","Saffron City Gym","city",5,"kanto","psychic","big-city"),
    R("r19","Route 19","water","kantoWater",[72,73,86,90,98,116,118,120,129],"swimmer","surf-channel"),
    R("seafoam","Seafoam Islands","water","kantoWater",[86,87,90,91,98,99,120,121,144],"swimmer","ice-islands"),
    R("r20","Route 20","water","kantoWater",[72,73,86,90,98,116,118,120,129],"swimmer","surf-channel"),
    R("cinnabar","Cinnabar Island","water","kantoWater",[58,77,72,90,98,129,132],"scientist","volcano-island"),
    R("mansion","Pokémon Mansion","cave","kantoCave",[37,58,77,88,109,126,132],"scientist","burned-mansion"),
    RG("blaine","Cinnabar Gym","city",6,"kanto","scientist","volcano-gym"),
    R("r21","Route 21","water","kantoWater",[16,17,72,90,98,116,118,129],"swimmer","surf-channel"),
    RG("viridianGym","Viridian Gym","city",7,"kanto","leader","city-garden"),
    R("r23","Route 23","mountain","kantoRoute",[21,22,23,24,27,28,56,57,66,67,74,75],"ace","badge-gates"),
    R("victory","Victory Road","cave","kantoCave",[42,74,75,95,105,111,112,146,147,148],"ace","victory-cave"),
    RE("indigo","Indigo Plateau","city","kanto",[87,91,95,124,130,142,149],"league")
  ];

  const JOHTO_V8 = [
    R("newbark","New Bark Town","city","johtoCity",[16,19,161,163],"youngster","small-town"),
    R("r29","Route 29","route","johtoRoute",[16,19,161,163,165],"youngster","west-east-grass"),
    R("cherrygrove","Cherrygrove City","city","johtoCity",[19,161,163,183],"gentleman","coastal-town"),
    R("r30","Route 30","route","johtoRoute",[10,13,16,19,161,163,165,187],"youngster","split-woods"),
    R("r31","Route 31 / Dark Cave","cave","johtoCave",[16,19,41,74,163,167,173,206],"bug","cave-gate"),
    RG("violet","Violet City Gym","city",0,"johto","birdkeeper","tower-city"),
    R("sprout","Sprout Tower","tower","johtoCity",[19,92,163,69,187],"sage","sprout-tower"),
    R("r32","Route 32","water","johtoRoute",[16,19,23,41,60,69,72,179,194],"fisher","long-coast"),
    R("ruins","Ruins of Alph","tower","johtoRare",[41,92,95,177,201,202,206],"psychic","ruins"),
    R("union","Union Cave","cave","johtoCave",[41,42,60,74,95,194,206],"hiker","union-cave"),
    R("r33","Route 33","route","johtoRoute",[19,21,23,41,69,187],"hiker","rain-route"),
    RG("azalea","Azalea Town Gym","forest",1,"johto","bug","forest-town"),
    R("slowpoke","Slowpoke Well","cave","johtoCave",[41,42,79,80,194],"rocket","well"),
    R("ilex","Ilex Forest","forest","johtoForest",[10,13,43,46,48,123,152,165,167,187,190,191,193,204],"bug","deep-forest"),
    R("r34","Route 34","route","johtoRoute",[16,19,39,52,63,96,132,179,183,209],"breeder","daycare-route"),
    RG("goldenrod","Goldenrod City Gym","city",2,"johto","beauty","big-city"),
    R("r35","Route 35","route","johtoRoute",[16,19,29,32,43,48,63,96,132,193],"bug","park-gate"),
    R("national","National Park","forest","johtoForest",[10,13,16,19,25,43,46,48,123,127,165,167,191,193,214],"bug","national-park"),
    R("r36","Route 36","route","johtoRoute",[16,17,39,43,69,185,191,193],"lass","sudowoodo-route"),
    R("r37","Route 37","route","johtoRoute",[16,17,37,39,58,163,164,167,234],"beauty","apricorns"),
    RG("ecruteak","Ecruteak City Gym","tower",3,"johto","psychic","tower-city"),
    R("burned","Burned Tower","tower","johtoCave",[19,20,41,42,92,93,109,110,200,243,244,245],"psychic","burned-tower"),
    R("r38","Route 38","route","johtoRoute",[19,20,39,52,81,82,128,179,180,241],"sailor","farm-road"),
    R("r39","Route 39 / Moomoo Farm","route","johtoRoute",[19,20,39,52,81,82,128,179,180,241],"sailor","farm-road"),
    RG("olivine","Olivine City Gym","water",5,"johto","sailor","harbor-city"),
    R("lighthouse","Glitter Lighthouse","tower","johtoWater",[170,171,179,180,181,120],"sailor","lighthouse"),
    R("r40","Route 40","water","johtoWater",[72,73,86,90,98,116,118,170,171,222,226],"swimmer","surf-channel"),
    R("r41","Route 41 / Whirl Islands","water","johtoWater",[72,73,86,87,98,99,116,117,170,171,223,226,249],"swimmer","whirl-sea"),
    RG("cianwood","Cianwood Gym","water",4,"johto","blackbelt","island-town"),
    R("r42","Route 42","mountain","johtoRoute",[21,22,41,42,60,66,74,179,180,183,185],"hiker","mountain-lakes"),
    R("mtmortar","Mt. Mortar","cave","johtoCave",[41,42,66,74,75,95,183,194,200,206,214],"hiker","mortar-cave"),
    R("r43","Route 43","route","johtoRoute",[16,17,43,48,96,132,164,179,180,183,203],"rocket","lake-road"),
    R("lake","Lake of Rage","water","johtoWater",[129,130,183,184,193,194],"fisher","red-gyarados"),
    R("rocket","Rocket Hideout","cave","johtoCave",[19,20,23,24,41,42,88,89,109,110,198],"rocket","rocket-base"),
    RG("mahogany","Mahogany Gym","city",6,"johto","hiker","snow-town"),
    R("r44","Route 44","water","johtoRoute",[16,17,43,44,60,61,69,70,108,114,179,180,183,194],"psychic","pond-route"),
    R("icepath","Ice Path","cave","johtoCave",[41,42,124,215,220,221,225,238],"hiker","ice-cave"),
    RG("blackthorn","Blackthorn Gym","mountain",7,"johto","ace","mountain-city"),
    R("dragonsden","Dragon's Den","water","johtoWater",[60,61,129,130,147,148,230],"ace","dragon-den"),
    R("r45","Route 45","mountain","johtoCave",[21,22,27,28,42,74,75,95,111,112,207,216,227],"ace","cliff-road"),
    R("r46","Route 46","mountain","johtoRoute",[19,20,21,22,27,28,74,75,216],"hiker","cliff-road"),
    R("r27","Route 27","water","johtoWater",[20,22,24,42,60,61,72,118,119,170,171,222],"ace","tohjo-shore"),
    R("tohjo","Tohjo Falls","cave","johtoWater",[42,60,61,79,80,118,119,130,170,171],"hiker","waterfall-cave"),
    R("r26","Route 26","mountain","johtoRoute",[20,22,24,42,60,61,77,78,84,85,114,164,216],"ace","badge-gates"),
    R("victoryj","Victory Road","cave","johtoCave",[42,74,75,95,217,221,227,246,247],"ace","victory-cave"),
    RE("indigoj","Indigo Plateau","city","johto",[178,169,68,197,149,248],"league")
  ];

  function campaign(){ return state?.region==='kanto'?KANTO_V8:JOHTO_V8; }
  function stageLevel(){ return Math.max(3, 5 + Math.floor(state.stageIndex*.75) + state.badges.length*2); }

  function stageNodes(s=stage()){
    const final = state.stageIndex>=campaign().length-1;
    const base = [
      {id:'start',x:270,y:58,kind:'start',label:'Entrada',next:['a','b']},
      {id:'a',x:132,y:178,kind:themeFirst(s),label:labelKind(themeFirst(s)),next:['c','d']},
      {id:'b',x:408,y:178,kind:'capture',label:'Poké Ball',next:['d','e']},
      {id:'c',x:92,y:320,kind:'item',label:'Item Found',next:['f']},
      {id:'d',x:270,y:320,kind:'trainer',label:trainerFor(s).label,next:['f','g']},
      {id:'e',x:448,y:320,kind:citySpecial(s),label:labelKind(citySpecial(s)),next:['g']},
      {id:'f',x:170,y:500,kind:themeSecond(s),label:labelKind(themeSecond(s)),next:['h']},
      {id:'g',x:370,y:500,kind:s.gym?'gym':(s.elite?'elite':'question'),label:s.gym?s.gym.name:(s.elite?'Elite Four':'Random Event'),next:['h']},
      {id:'h',x:270,y:674,kind:s.elite?'champion':'trainer',label:s.elite?'Champion':trainerFor(s).label,next:['i']},
      {id:'i',x:270,y:820,kind:'exit',label:final?'Hall of Fame':'Próxima Área',next:[]}
    ];
    if(s.theme==='city'){
      base[1].kind='heal'; base[1].label='Pokémon Center';
      base[2].kind='shop'; base[2].label='Mart';
      base[4].kind=s.gym?'gym':'trainer'; base[4].label=s.gym?s.gym.name:trainerFor(s).label;
      base[5].kind='question'; base[5].label='City Event';
      base[6].kind='capture'; base[6].label='Poké Ball';
    }
    if(s.theme==='water'){
      base[1].kind='battle'; base[1].label='Surf Battle';
      base[2].kind='capture'; base[2].label='Poké Ball';
      base[3].kind='item'; base[3].label='Hidden Item';
      base[5].kind='trainer'; base[5].label='Swimmer';
      base[6].kind='battle'; base[6].label='Wild Battle';
    }
    if(s.theme==='cave'||s.theme==='tower'){
      base[1].kind='battle'; base[1].label='Wild Battle';
      base[2].kind='item'; base[2].label='Item Found';
      base[5].kind='trainer'; base[5].label=trainerFor(s).label;
      base[6].kind='capture'; base[6].label='Poké Ball';
    }
    if(s.elite){
      base[1].kind='heal'; base[1].label='Pokémon Center';
      base[2].kind='item'; base[2].label='Final Supplies';
      base[4].kind='elite'; base[4].label='Elite Four';
      base[5].kind='elite'; base[5].label='Elite Four';
      base[6].kind='elite'; base[6].label='Elite Four';
      base[7].kind='champion'; base[7].label='Champion';
      base[8].label='Hall of Fame';
    }
    return base;
  }

  function classKeyForStage(s){
    if(s?.trainer) {
      const alias={birdkeeper:'ace',gambler:'gentleman',fisher:'sailor',sage:'psychic',breeder:'lass',blackbelt:'hiker'};
      return TRAINER_CLASSES[s.trainer]?s.trainer:(alias[s.trainer]||'youngster');
    }
    const map={forest:'bug',cave:'hiker',water:'swimmer',tower:'psychic',mountain:'ace',city:'gentleman',route:'youngster'};
    return map[s.theme]||'youngster';
  }
  function trainerFor(s){ return TRAINER_CLASSES[classKeyForStage(s)]||TRAINER_CLASSES.youngster; }

  function drawBackground(ctx,s,seed){
    const W=540,H=890, rnd=mulberry(seed); ctx.clearRect(0,0,W,H);
    if(s.theme==='city') drawNamedCity(ctx,s,seed);
    else if(s.theme==='forest') drawNamedForest(ctx,s,seed);
    else if(s.theme==='cave'||s.theme==='tower') drawNamedCaveOrTower(ctx,s,seed);
    else if(s.theme==='water') drawNamedWater(ctx,s,seed);
    else if(s.theme==='mountain') drawNamedMountain(ctx,s,seed);
    else drawNamedRoute(ctx,s,seed);
    drawMapLabel(ctx,s);
    for(let i=0;i<620;i++){ const x=Math.floor(rnd()*W), y=Math.floor(rnd()*H); ctx.fillStyle=`rgba(255,255,255,${rnd()*.10})`; ctx.fillRect(x,y,2,2); }
  }

  function drawMapLabel(ctx,s){
    ctx.fillStyle='rgba(255,255,255,.85)'; ctx.fillRect(16,16,250,32);
    ctx.strokeStyle='#111'; ctx.lineWidth=2; ctx.strokeRect(16,16,250,32);
    ctx.fillStyle='#3b342c'; ctx.font='10px monospace'; ctx.fillText(s.name.slice(0,34),26,37);
  }
  function routeNum(id){ const m=String(id).match(/r(\d+)/); return m?+m[1]:0; }
  function isKantoStage(s){ return KANTO_V8.some(x=>x.id===s.id); }
  function paletteFor(s){ const k=isKantoStage(s); return k?{grass:'#69d89c',grass2:'#4fc885',tree:'#28763b',tree2:'#3e9b46',path:'#d9be73',road:'#d6ceb0',water:'#55bfe8',water2:'#318dcc',sand:'#e7d193',rock:'#837b73',city:'#b6c4ab'}:{grass:'#65d6aa',grass2:'#42bf8c',tree:'#2e7842',tree2:'#3d9454',path:'#d8b873',road:'#d2c5a0',water:'#56b8e5',water2:'#2e86c1',sand:'#e9ce8b',rock:'#857870',city:'#aac2a8'}; }

  function drawNamedRoute(ctx,s,seed){
    const C=paletteFor(s), rn=routeNum(s.id), rnd=mulberry(seed+101);
    fill(ctx,0,0,540,890,C.grass);
    // route-specific top-to-bottom walk path
    const bend = (rn%5-2)*36;
    drawPath(ctx,270,42,270+bend,850,C.path, rn===17?72:52, seed+12);
    // special route structures
    if(['urban-route','short-city-route','city-edge'].includes(s.layout)){ drawRoadGrid(ctx,C); }
    if(['fence-route','maze-fence'].includes(s.layout)){ drawFences(ctx,seed); }
    if(s.layout==='cycling-road'||s.layout==='cycling-gate'||s.layout==='cycling-exit'){ drawCyclingRoad(ctx,C,seed); }
    if(s.layout==='bridge'||s.layout==='dock-bridge'){ drawBridge(ctx,C,seed); }
    if(s.layout==='daycare-route') { house(ctx,54,610,'#e9ca4d'); fill(ctx,48,710,132,54,'#9ed77a'); }
    if(s.layout==='farm-road'){ drawFarm(ctx,seed); }
    if(s.layout==='sudowoodo-route'){ tree(ctx,276,452,true); fill(ctx,242,494,72,14,'#8a6a3a'); }
    if(s.layout==='apricorns'){ for(let i=0;i<8;i++) apricornTree(ctx,70+(i%2)*390,120+i*80,['#d34646','#4fa6d9','#f1e05a','#54bf62'][i%4]); }
    if(s.layout==='lake-road'||s.layout==='pond-route'){ drawPond(ctx,390,270,105,78,C); drawPond(ctx,130,630,95,70,C); }
    if(s.layout==='west-east-grass') drawPath(ctx,40,180,500,180,C.path,42,seed+3);
    if(s.layout==='split-woods') drawPath(ctx,110,60,440,840,C.path,38,seed+4);
    // grass and trees adjusted by route number
    drawTrees(ctx, rn%3===0?'dense':'normal', seed+5);
    scatter(ctx,C.grass2, rn%2?62:84, seed+9);
    if(rn===24||rn===25){ drawPond(ctx,80,260,120,72,C); drawPond(ctx,340,610,110,76,C); }
    if(rn>=13&&rn<=15) drawFences(ctx,seed+33);
    if(rn>=5&&rn<=8) drawRoadGrid(ctx,C);
    if(rn>=38&&rn<=39) drawFarm(ctx,seed+2);
  }

  function drawNamedMountain(ctx,s,seed){
    const C=paletteFor(s), rn=routeNum(s.id);
    fill(ctx,0,0,540,890,'#77ca89');
    drawPath(ctx,270,42,240+(rn%4)*25,852,C.path,44,seed+21);
    for(let y=90;y<840;y+=90){ fill(ctx,30,y,160,26,C.rock); fill(ctx,350,y+35,160,26,C.rock); }
    drawRocks(ctx,seed+13); drawTrees(ctx,'mountain',seed+6); scatter(ctx,'#8bcf87',48,seed);
    if(['badge-gates','rival-road'].includes(s.layout)){ for(let y=180;y<770;y+=140){ gate(ctx,205,y); } }
    if(s.layout==='mountain-lakes'){ drawPond(ctx,72,185,125,86,C); drawPond(ctx,340,575,130,90,C); }
    if(s.layout==='cliff-road'){ for(let y=90;y<820;y+=80){ fill(ctx,0,y,540,18,'#6c665d'); fill(ctx,0,y+18,540,8,'#4c473e'); } }
  }

  function drawNamedForest(ctx,s,seed){
    const C=paletteFor(s);
    fill(ctx,0,0,540,890,'#4fc886');
    drawPath(ctx,270,40,270,850,C.path,42,seed+31);
    drawPath(ctx,95,160,445,720,C.path,32,seed+32);
    drawTrees(ctx,'dense',seed+5); drawTrees(ctx,'dense',seed+50);
    if(s.layout==='safari'){ drawPond(ctx,380,210,120,82,C); drawPond(ctx,95,660,130,92,C); fill(ctx,385,520,90,78,'#e5c982'); }
    if(s.layout==='national-park'){ fill(ctx,74,96,392,260,'#91d77b'); fill(ctx,96,120,348,215,'#bce596'); drawFences(ctx,seed+5); }
    if(s.layout==='forest-town'){ house(ctx,70,80,'#2bb7b6'); house(ctx,355,100,'#e35555'); }
  }

  function drawNamedCaveOrTower(ctx,s,seed){
    const rnd=mulberry(seed+20), tower=s.theme==='tower';
    fill(ctx,0,0,540,890,tower?'#5d5268':'#5b554e');
    drawPath(ctx,270,42,270,850,tower?'#8b7694':'#8d806c',64,seed+41);
    for(let i=0;i<135;i++){ const x=rnd()*540,y=rnd()*890; fill(ctx,x,y,24+rnd()*20,12+rnd()*15,rnd()<.5?'#3f3a35':'#756d63'); }
    if(tower || ['sprout-tower','burned-tower','ruins','lighthouse'].includes(s.layout)){
      fill(ctx,74,70,392,750,'#6d6176'); fill(ctx,98,96,344,700,'#7a6c84');
      for(let y=130;y<740;y+=122){ fill(ctx,114,y,312,14,'#4a354d'); fill(ctx,130,y-20,22,54,'#2e2534'); fill(ctx,386,y-20,22,54,'#2e2534'); }
    }
    if(['ice-cave'].includes(s.layout)){ fill(ctx,0,0,540,890,'rgba(133,220,245,.35)'); for(let i=0;i<10;i++) drawIcePatch(ctx,60+(i%3)*160,120+Math.floor(i/3)*165); }
    if(['waterfall-cave'].includes(s.layout)){ drawPond(ctx,185,110,170,680,{water:'#4dbbe5',water2:'#2e82bd'}); }
    if(['moon-cave','victory-cave','mortar-cave'].includes(s.layout)){ for(let i=0;i<6;i++) fill(ctx,60+rnd()*400,100+rnd()*700,55,38,'#8d857b'); }
  }

  function drawNamedWater(ctx,s,seed){
    const C=paletteFor(s), rnd=mulberry(seed+30);
    fill(ctx,0,0,540,890,C.water);
    for(let y=0;y<890;y+=38){ ctx.strokeStyle='rgba(255,255,255,.45)'; ctx.lineWidth=3; ctx.beginPath(); for(let x=0;x<560;x+=40){ if(x===0)ctx.moveTo(x,y+Math.sin((x+y)/60)*8); else ctx.lineTo(x,y+Math.sin((x+y)/60)*8); } ctx.stroke(); }
    drawPath(ctx,270,42,270,850,'#d6b16c',30,seed+4);
    if(['harbor-city','coastal-town','island-town','volcano-island'].includes(s.layout)){ drawIslandTown(ctx,s,seed); }
    else if(['surf-channel','whirl-sea','ice-islands'].includes(s.layout)){ for(let i=0;i<5;i++){ const x=70+rnd()*360,y=90+rnd()*670; fill(ctx,x,y,95,60,C.sand); fill(ctx,x+12,y+10,70,42,'#72be66'); } }
    else if(s.layout==='canal-city'){ drawCanalCity(ctx,C); }
    else { fill(ctx,65,620,145,95,C.sand); fill(ctx,340,150,120,80,C.sand); }
    if(s.layout==='power-plant'){ house(ctx,335,120,'#d6d257'); fill(ctx,372,95,45,70,'#909090'); }
    if(s.layout==='red-gyarados'){ drawPond(ctx,40,60,460,760,C); ctx.fillStyle='#d53b30'; ctx.beginPath(); ctx.arc(270,435,24,0,7); ctx.fill(); }
  }

  function drawNamedCity(ctx,s,seed){
    const C=paletteFor(s); fill(ctx,0,0,540,890,C.city);
    drawRoadGrid(ctx,C);
    const roofs=['#e35555','#2bb7b6','#d9b34a','#6c8ed9'];
    for(let i=0;i<8;i++){ const x=60+(i%2)*330, y=82+Math.floor(i/2)*160; house(ctx,x,y,roofs[i%roofs.length]); }
    house(ctx,222,118,'#e35555'); house(ctx,222,328,'#2bb7b6');
    if(s.gym) gym(ctx,205,560,s.gym.type);
    if(['big-city'].includes(s.layout)){ for(let y=80;y<760;y+=132){ fill(ctx,185,y,170,88,'#c9c5b3'); fill(ctx,198,y+12,40,25,'#8ed6e6'); fill(ctx,252,y+12,40,25,'#8ed6e6'); } }
    if(['harbor-city','canal-city','coastal-town','island-town','volcano-island'].includes(s.layout)){ fill(ctx,0,650,540,240,C.water); fill(ctx,42,620,456,55,'#c29b62'); }
    if(s.layout==='tower-city'){ fill(ctx,388,70,74,190,'#755f68'); fill(ctx,407,36,35,40,'#4c3c43'); }
    if(s.layout==='museum-city'){ fill(ctx,54,82,166,86,'#d2d0c0'); ctx.fillStyle='#423b31'; ctx.font='9px monospace'; ctx.fillText('MUSEUM',96,132); }
    if(s.layout==='snow-town'){ fill(ctx,0,0,540,890,'rgba(245,250,255,.35)'); }
    if(s.layout==='league'){ fill(ctx,110,120,320,220,'#d7d9df'); fill(ctx,82,92,376,48,'#6d7587'); ctx.fillStyle='#fff'; ctx.font='18px monospace'; ctx.fillText('INDIGO PLATEAU',152,210); }
  }

  function drawRoadGrid(ctx,C){
    fill(ctx,230,0,82,890,C.road); fill(ctx,0,384,540,78,C.road); fill(ctx,48,0,66,890,C.road); fill(ctx,426,0,66,890,C.road);
    ctx.strokeStyle='#a99d7c'; ctx.lineWidth=3; ctx.setLineDash([10,10]); ctx.beginPath(); ctx.moveTo(270,0); ctx.lineTo(270,890); ctx.moveTo(0,423); ctx.lineTo(540,423); ctx.stroke(); ctx.setLineDash([]);
  }
  function drawFences(ctx,seed){ for(let y=130;y<820;y+=95){ for(let x=35;x<500;x+=35){ fill(ctx,x,y,24,8,'#916a3e'); fill(ctx,x+6,y-8,5,24,'#6b4c2e'); } } }
  function drawCyclingRoad(ctx,C,seed){ fill(ctx,180,0,180,890,'#bba36a'); fill(ctx,198,0,144,890,'#d5c07d'); for(let y=40;y<870;y+=70){ fill(ctx,210,y,120,6,'#9c8758'); } }
  function drawBridge(ctx,C,seed){ fill(ctx,0,0,540,890,C.water); drawPath(ctx,270,40,270,850,'#c28e51',58,seed); for(let y=92;y<820;y+=70){ fill(ctx,216,y,108,8,'#8a6032'); } fill(ctx,52,115,120,90,C.grass); fill(ctx,368,640,120,90,C.grass); }
  function drawFarm(ctx,seed){ fill(ctx,48,110,170,160,'#b7d77a'); fill(ctx,62,124,142,132,'#dbe88a'); house(ctx,355,590,'#df6b55'); for(let i=0;i<8;i++) fill(ctx,70+(i%4)*28,150+Math.floor(i/4)*48,16,16,'#fff'); }
  function drawPond(ctx,x,y,w,h,C){ ctx.fillStyle=C.water||'#55bfe8'; ctx.beginPath(); ctx.ellipse(x+w/2,y+h/2,w/2,h/2,0,0,7); ctx.fill(); ctx.strokeStyle=C.water2||'#318dcc'; ctx.lineWidth=5; ctx.stroke(); }
  function gate(ctx,x,y){ fill(ctx,x,y,130,74,'#d9d0b8'); fill(ctx,x+38,y+34,54,40,'#4b3b35'); fill(ctx,x-8,y-12,146,24,'#7f6f5a'); }
  function apricornTree(ctx,x,y,c){ tree(ctx,x,y,true); ctx.fillStyle=c; ctx.beginPath(); ctx.arc(x+16,y-9,5,0,7); ctx.arc(x-12,y-3,5,0,7); ctx.fill(); }
  function drawIslandTown(ctx,s,seed){ const C=paletteFor(s); fill(ctx,74,92,392,700,C.sand); fill(ctx,92,122,356,640,'#7bc66d'); drawRoadGrid(ctx,C); if(s.gym) gym(ctx,205,560,s.gym.type); house(ctx,75,170,'#e35555'); house(ctx,360,200,'#2bb7b6'); }
  function drawCanalCity(ctx,C){ fill(ctx,0,0,540,890,C.city); fill(ctx,205,0,130,890,C.water); fill(ctx,0,360,540,110,C.water); fill(ctx,180,330,180,34,'#c28e51'); fill(ctx,180,470,180,34,'#c28e51'); fill(ctx,230,0,80,890,C.road); fill(ctx,0,390,540,54,C.road); house(ctx,70,80,'#e35555'); house(ctx,370,80,'#2bb7b6'); gym(ctx,205,565,'water'); }
  function drawIcePatch(ctx,x,y){ fill(ctx,x,y,110,70,'rgba(230,255,255,.65)'); ctx.strokeStyle='rgba(255,255,255,.95)'; ctx.strokeRect(x+8,y+8,94,54); }

})();
