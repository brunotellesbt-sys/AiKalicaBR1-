(() => {
  const $ = (sel) => document.querySelector(sel);
  const nodesEl = $('#nodes');
  const routesEl = $('#routes');
  const hero = $('#hero');
  const toast = $('#toast');
  const modal = $('#modal');
  const modalTitle = $('#modalTitle');
  const modalText = $('#modalText');
  const modalContent = $('#modalContent');
  const modalPrimary = $('#modalPrimary');
  const modalSecondary = $('#modalSecondary');
  const teamList = $('#teamList');
  const itemsList = $('#itemsList');
  const badgesEl = $('#badges');

  const nodes = [
    { id: 'start', type: 'start', x: 50, y: 96, title: 'Start' },
    { id: 'grass1', type: 'grass', x: 34, y: 85, title: 'Wild Grass' },
    { id: 'chest1', type: 'chest', x: 73, y: 86, title: 'Item' },
    { id: 'question1', type: 'question', x: 20, y: 73, title: 'Mystery' },
    { id: 'grass2', type: 'grass', x: 50, y: 74, title: 'Wild Grass' },
    { id: 'question2', type: 'question', x: 82, y: 73, title: 'Mystery' },
    { id: 'boss1', type: 'boss', x: 19, y: 63, title: 'Trainer' },
    { id: 'wild1', type: 'wild', x: 38, y: 63, title: 'Wild Pokémon' },
    { id: 'gym1', type: 'gym', x: 62, y: 63, title: 'Badge Battle' },
    { id: 'grass3', type: 'grass', x: 81, y: 63, title: 'Wild Grass' },
    { id: 'trainer1', type: 'trainer', x: 15, y: 50, title: 'Trainer' },
    { id: 'wild2', type: 'wild', x: 38, y: 50, title: 'Wild Pokémon' },
    { id: 'heal1', type: 'heal', x: 80, y: 51, title: 'Heal' },
    { id: 'trainer2', type: 'trainer', x: 62, y: 39, title: 'Trainer' },
    { id: 'grass4', type: 'grass', x: 37, y: 39, title: 'Wild Grass' },
    { id: 'trainer3', type: 'trainer', x: 15, y: 38, title: 'Trainer' },
    { id: 'boss2', type: 'boss', x: 50, y: 30, title: 'Rival' },
    { id: 'trainer4', type: 'trainer', x: 82, y: 38, title: 'Trainer' },
    { id: 'pokeball1', type: 'pokeball', x: 27, y: 16, title: 'Poké Ball' },
    { id: 'grass5', type: 'grass', x: 75, y: 16, title: 'Wild Grass' },
    { id: 'finish', type: 'boss', x: 50, y: 4, title: 'Gym Gate' }
  ];

  const routes = [
    ['start', 'grass1'], ['start', 'chest1'],
    ['grass1', 'question1'], ['grass1', 'grass2'],
    ['chest1', 'grass2'], ['chest1', 'question2'],
    ['question1', 'boss1'], ['question1', 'wild1'],
    ['grass2', 'wild1'], ['grass2', 'gym1'],
    ['question2', 'gym1'], ['question2', 'grass3'],
    ['boss1', 'trainer1'], ['wild1', 'trainer1'], ['wild1', 'wild2'],
    ['gym1', 'trainer2'], ['gym1', 'heal1'],
    ['grass3', 'heal1'], ['grass3', 'trainer4'],
    ['trainer1', 'trainer3'], ['wild2', 'trainer3'], ['wild2', 'grass4'],
    ['trainer2', 'grass4'], ['trainer2', 'boss2'], ['heal1', 'trainer4'],
    ['trainer3', 'pokeball1'], ['grass4', 'pokeball1'], ['grass4', 'boss2'],
    ['boss2', 'pokeball1'], ['boss2', 'grass5'], ['trainer4', 'grass5'],
    ['pokeball1', 'finish'], ['grass5', 'finish']
  ];

  const byId = Object.fromEntries(nodes.map((node) => [node.id, node]));
  const wildMons = [
    { name: 'Pidgey', level: 4, css: 'sprite-bug' },
    { name: 'Rattata', level: 5, css: 'sprite-water' },
    { name: 'Mareep', level: 6, css: 'sprite-bug' },
    { name: 'Zubat', level: 6, css: 'sprite-water' }
  ];
  const items = ['Potion', 'Rare Candy', 'Poké Ball', 'Berry'];

  const defaultState = {
    current: 'start',
    visited: ['start'],
    team: [{ name: 'Cyndaquil', level: 5, hp: 100, css: 'sprite-fire' }],
    bag: [],
    badges: 0,
    cleared: false
  };
  let state = loadState();

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem('pokelike-layout-v3') || 'null');
      if (saved && saved.current && Array.isArray(saved.team)) return saved;
    } catch (_) {}
    return structuredClone(defaultState);
  }

  function saveState() {
    localStorage.setItem('pokelike-layout-v3', JSON.stringify(state));
  }

  function connected(a, b) {
    return routes.some(([x, y]) => (x === a && y === b) || (x === b && y === a));
  }

  function nextReachable(id) {
    return connected(state.current, id) || state.visited.includes(id);
  }

  function renderRoutes() {
    routesEl.innerHTML = '';
    routes.forEach(([a, b]) => {
      const n1 = byId[a];
      const n2 = byId[b];
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', n1.x);
      line.setAttribute('y1', n1.y);
      line.setAttribute('x2', n2.x);
      line.setAttribute('y2', n2.y);
      routesEl.appendChild(line);
    });
  }

  function renderNodes() {
    nodesEl.innerHTML = '';
    nodes.forEach((node) => {
      const button = document.createElement('button');
      button.className = `map-node node-${node.type}`;
      button.style.left = `${node.x}%`;
      button.style.top = `${node.y}%`;
      button.title = node.title;
      button.setAttribute('aria-label', node.title);
      button.innerHTML = '<span class="node-art"></span>';
      if (state.visited.includes(node.id) && node.id !== state.current) button.classList.add('visited');
      if (!nextReachable(node.id)) button.classList.add('locked');
      button.addEventListener('click', () => moveTo(node.id));
      nodesEl.appendChild(button);
    });
  }

  function renderHero() {
    const node = byId[state.current];
    hero.style.left = `${node.x}%`;
    hero.style.top = `${node.y}%`;
  }

  function renderTeam() {
    teamList.innerHTML = '';
    state.team.slice(0, 6).forEach((mon, index) => {
      const card = document.createElement('div');
      card.className = 'team-card';
      card.innerHTML = `
        <div class="sprite-mini ${mon.css || 'sprite-fire'}"></div>
        <div>${escapeHtml(mon.name)}</div>
        <div class="level">Lv${mon.level}</div>
        <div class="hp-shell"><div class="hp-bar" style="width:${Math.max(4, mon.hp || 100)}%"></div></div>
      `;
      card.addEventListener('click', () => {
        if (index > 0) {
          const [picked] = state.team.splice(index, 1);
          state.team.unshift(picked);
          showToast('Team swapped');
          saveState();
          render();
        } else {
          showToast('Lead Pokémon');
        }
      });
      teamList.appendChild(card);
    });
  }

  function renderBag() {
    if (!state.bag.length) {
      itemsList.textContent = 'Bag empty';
      return;
    }
    itemsList.innerHTML = state.bag.map((item) => `<span class="item-pill">${escapeHtml(item)}</span>`).join('');
  }

  function renderBadges() {
    badgesEl.innerHTML = '';
    for (let i = 0; i < 8; i++) {
      const badge = document.createElement('div');
      badge.className = `badge${i < state.badges ? ' earned' : ''}`;
      badgesEl.appendChild(badge);
    }
  }

  function render() {
    renderRoutes();
    renderNodes();
    renderHero();
    renderTeam();
    renderBag();
    renderBadges();
  }

  function moveTo(id) {
    if (id === state.current) return;
    if (!nextReachable(id)) {
      showToast('Choose a connected node');
      return;
    }
    state.current = id;
    if (!state.visited.includes(id)) state.visited.push(id);
    saveState();
    render();
    setTimeout(() => triggerEvent(byId[id]), 280);
  }

  function triggerEvent(node) {
    switch (node.type) {
      case 'grass': return wildEncounter(false);
      case 'wild': return wildEncounter(true);
      case 'pokeball': return findItem('Poké Ball');
      case 'chest': return findItem(random(items));
      case 'question': return mysteryEvent();
      case 'heal': return healTeam();
      case 'gym': return gymBattle();
      case 'trainer':
      case 'boss': return trainerBattle(node.id === 'finish');
      default: return showToast(node.title);
    }
  }

  function trainerBattle(isFinish) {
    const enemy = isFinish ? 'Champion' : random(['Bug Catcher', 'Rival', 'Lass', 'Hiker']);
    const lead = state.team[0];
    lead.level += isFinish ? 2 : 1;
    lead.hp = Math.max(38, lead.hp - (isFinish ? 22 : 13));
    openModal({
      title: 'Wild Battle!',
      text: `${enemy} challenged you. ${lead.name} wins and reaches Lv${lead.level}.`,
      content: battleContent(lead, enemy),
      primary: isFinish ? 'Champion!' : 'Continue',
      secondary: 'Close',
      onPrimary: () => {
        if (isFinish) champion(); else closeModal();
      }
    });
    saveState();
    render();
  }

  function wildEncounter(forceCatch) {
    const mon = { ...random(wildMons) };
    openModal({
      title: '⬟ Wild Pokemon Appeared!',
      text: `Choose one Pokemon to add to your team.`,
      content: `<div class="choice-grid"><div class="choice"><div class="sprite-mini ${mon.css}"></div><strong>${mon.name}</strong><br>Lv${mon.level}</div></div>`,
      primary: forceCatch ? 'Add to team' : 'Catch',
      secondary: 'Skip (flee)',
      onPrimary: () => {
        if (state.team.length >= 6) {
          showToast('Team Full!');
        } else {
          state.team.push({ ...mon, hp: 100 });
          showToast(`${mon.name} joined!`);
        }
        saveState();
        render();
        closeModal();
      }
    });
  }

  function findItem(item) {
    state.bag.push(item);
    saveState();
    render();
    openModal({
      title: '✦ Item Found!',
      text: 'Choose one item to keep.',
      content: `<div class="choice">${escapeHtml(item)}</div>`,
      primary: 'Keep',
      secondary: 'Skip',
      onPrimary: closeModal
    });
  }

  function mysteryEvent() {
    const outcome = random(['trade', 'item', 'heal']);
    if (outcome === 'trade' && state.team.length > 1) {
      const offered = { name: 'Togepi', level: Math.max(5, state.team[0].level - 1), hp: 100, css: 'sprite-bug' };
      openModal({
        title: '⇄ Trade Offer',
        text: `Trade ${state.team[state.team.length - 1].name} for ${offered.name}?`,
        content: `<div class="choice"><div class="sprite-mini ${offered.css}"></div>${offered.name}<br>Lv${offered.level}</div>`,
        primary: 'Trade',
        secondary: 'Decline',
        onPrimary: () => {
          state.team.pop();
          state.team.push(offered);
          saveState();
          render();
          closeModal();
          showToast('Trade complete');
        }
      });
    } else if (outcome === 'item') {
      findItem(random(items));
    } else {
      healTeam();
    }
  }

  function healTeam() {
    state.team.forEach((mon) => { mon.hp = 100; });
    saveState();
    render();
    openModal({
      title: 'Team Restored!',
      text: 'Your team was healed before the next battle.',
      content: '',
      primary: 'Continue',
      secondary: 'Close',
      onPrimary: closeModal
    });
  }

  function gymBattle() {
    state.badges = Math.min(8, state.badges + 1);
    state.team.forEach((mon) => { mon.level += 1; mon.hp = 100; });
    saveState();
    render();
    openModal({
      title: 'Badge Earned!',
      text: `Badges: ${state.badges}/8`,
      content: '<div class="badge earned"></div>',
      primary: 'Next Map →',
      secondary: 'Close',
      onPrimary: closeModal
    });
  }

  function champion() {
    openModal({
      title: 'YOU ARE THE CHAMPION!',
      text: 'Congratulations! You defeated the Elite Four!',
      content: '<div class="choice">Hall of Fame saved locally.</div>',
      primary: 'Play Again',
      secondary: 'Close',
      onPrimary: () => {
        localStorage.removeItem('pokelike-layout-v3');
        state = structuredClone(defaultState);
        closeModal();
        render();
      }
    });
  }

  function battleContent(lead, enemy) {
    return `<div class="battle-box">
      <div class="battle-mon"><strong>Your Team</strong>${escapeHtml(lead.name)}<br>Lv${lead.level}<div class="hp-shell"><div class="hp-bar" style="width:${lead.hp}%"></div></div></div>
      <div class="battle-mon"><strong>Enemy</strong>${escapeHtml(enemy)}<br>Defeated</div>
    </div>`;
  }

  function openModal({ title, text, content, primary, secondary, onPrimary }) {
    modalTitle.textContent = title || '';
    modalText.textContent = text || '';
    modalContent.innerHTML = content || '';
    modalPrimary.textContent = primary || 'Continue';
    modalSecondary.textContent = secondary || 'Skip';
    modalPrimary.onclick = onPrimary || closeModal;
    modalSecondary.onclick = closeModal;
    modal.classList.remove('hidden');
  }

  function closeModal() { modal.classList.add('hidden'); }

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove('show'), 1400);
  }

  function random(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function escapeHtml(text) {
    return String(text).replace(/[&<>'"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[ch]));
  }

  $('#dismissTip').addEventListener('click', (event) => {
    event.currentTarget.style.display = 'none';
  });

  render();
})();
