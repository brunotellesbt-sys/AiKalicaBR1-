# Pokelike Kanto & Johto v8

Versão estática para GitHub Pages com GitHub Actions.

## Correções desta versão

- Progressão do mapa de cima para baixo.
- Kanto e Johto remodelados por rotas, cidades, cavernas, torres, mar e ginásios.
- Cada rota/cidade recebe mapa fan-made coerente com seu tipo: ponte, floresta, caverna, mar, cycling road, fazenda, lago, torre, cidade grande, porto etc.
- Wild Battle é apenas batalha.
- Poké Ball é captura.
- NPC do mapa usa a mesma classe visual do NPC dentro da batalha.
- Pokédex com 251 Pokémon e sprites de Pokémon carregados da PokéAPI/sprites quando há internet.

Abra `index.html` localmente ou publique pelo workflow do GitHub Pages.
