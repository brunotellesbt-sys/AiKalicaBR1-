# Pokelike - GitHub Pages

Versão remodulada para GitHub Pages usando o layout de mapa vertical com painéis laterais e textura visual extraída da referência enviada pelo usuário.

## Arquivos principais

- `index.html`
- `style.css`
- `game.js`
- `assets/textures/map-original-crop.png`
- `.nojekyll`

## Publicação com GitHub Actions

O workflow espera que este site esteja compactado como:

```txt
pokelike-site-for-actions.zip
```

na raiz do repositório.
