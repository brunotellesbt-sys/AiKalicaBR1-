# Pokelike GitHub Pages

Versão estática em HTML/CSS/JS puro, remodelada para ficar próxima do layout de mapa do Pokelike: mapa vertical central, painéis laterais de TEAM, ITEMS e BADGES, rotas pontilhadas e eventos clicáveis.

## Rodar localmente

Abra `index.html` no navegador.

## Publicar com GitHub Actions

Este site foi empacotado para ser usado dentro de `pokelike-site-for-actions.zip`. O workflow `deploy-pokelike-pages.yml` descompacta esse ZIP e publica no GitHub Pages.
